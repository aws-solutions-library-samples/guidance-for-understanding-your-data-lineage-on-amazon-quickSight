#Import Libraries to use
import csv
import os
import time
import traceback
import boto3
import json
import base64
import urllib3
from datetime import datetime

true=True
false=False

SUCCESS = "SUCCESS"
FAILED = "FAILED"

resID={}

awsAccountId=os.environ["AwsAccountId"]
LambdaFunctionName=os.environ["LambdaFunctionName"]
DataLineageBucket=os.environ["DataLineageBucket"]
databaseName=os.environ["databaseName"]
namespace=os.environ["namespace"]
codeBucket=os.environ["codeBucket"]
userName=os.environ["userName"]
qsImportJobID=os.environ["qsImportJobID"]
#suffix=os.environ["suffix"]
#region=os.environ["Region"]

s3 = boto3.client('s3')
quicksight = boto3.client('quicksight')
lambdaClient = boto3.client('lambda')
athena = boto3.client('athena')

path="/tmp/"

#Generate Analysis/Dashboard data as CSV
def getAnalysisDashboardName(resourceName,ID,QuicksightResource):
    try:
        dataFilePath=path+resourceName
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_name.csv")
        #Write to CSV file
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        csvWriter.writerow([resourceName+"_Name",resourceName+"_ID","Theme","ResourceStatus"])
        #Get the Analysis
        ResourceName=QuicksightResource["Name"]
        ResourceID=QuicksightResource[resourceName+"Id"]
        #Check if Theme is present
        if "ThemeArn" in QuicksightResource:
            ResourceTheme=QuicksightResource["ThemeArn"].split("/")[-1]
        else:
            ResourceTheme=None
        #Check if ResourceStatus is present
        if "ResourceStatus" in QuicksightResource:
            ResourceStatus=QuicksightResource["ResourceStatus"]
        else:
            ResourceStatus=None
        csvWriter.writerow([ResourceName,ResourceID,ResourceTheme,ResourceStatus])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile,DataLineageBucket,resourceName+"/"+resourceName+"_"+ID+"_name.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_name.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" Name",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" Name",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_name.csv")
    return

#Generate DataSets data as CSV
def getResourceDataSets(resourceName,ID,QuicksightResource):
    try:
        #Check if QuicksightResource["Definition"]["DataSetIdentifierDeclarations"] length > 0
        if len(QuicksightResource["Definition"]["DataSetIdentifierDeclarations"]) > 0:
            dataFilePath=path+resourceName+"DataSets"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_datasets.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["DataSet_Name","DataSet_ID",resourceName+"_ID"])
            #Get the DataSets
            for DataSet in QuicksightResource["Definition"]["DataSetIdentifierDeclarations"]:
                DataSetName=DataSet["Identifier"]
                #Split the DataSetArn to get the DataSetID
                DataSetID=DataSet["DataSetArn"].split("/")[-1]
                csvWriter.writerow([DataSetName,DataSetID,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile, DataLineageBucket, resourceName+"DataSets"+"/"+resourceName+"_"+ID+"_datasets.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_datasets.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" DataSets",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" DataSets",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        print()
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_datasets.csv")
    return

#Generate Calculated Fields data as CSV
def getCalculatedFields(resourceName,ID,QuicksightResource):
    try:
        #Get the Calculated Fields if CalculatedFields length is greater than 0
        if len(QuicksightResource["Definition"]["CalculatedFields"])>0:
            dataFilePath=path+resourceName+"CalculatedFields"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_calculatedfields.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["CF_DataSet_Name","Calculated_Field_Name","Calculated_Field_Expression",resourceName+"_ID"])
            for CalculatedField in QuicksightResource["Definition"]["CalculatedFields"]:
                #Check if DataSetIdentifier is present
                if "DataSetIdentifier" in CalculatedField:
                    DataSetName=CalculatedField["DataSetIdentifier"]
                else:
                    DataSetName="None"
                #Check if Name is present
                if "Name" in CalculatedField:
                    CalculatedFieldName=CalculatedField["Name"]
                else:
                    CalculatedFieldName="None"
                #Check if Expression is present
                if "Expression" in CalculatedField:
                    CalculatedFieldExpression=CalculatedField["Expression"]
                else:
                    CalculatedFieldExpression="None"
                csvWriter.writerow([DataSetName,CalculatedFieldName,CalculatedFieldExpression,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile, DataLineageBucket, resourceName+"CalculatedFields"+"/"+resourceName+"_"+ID+"_calculatedfields.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_calculatedfields.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" CalculatedFields",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" CalculatedFields",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_calculatedfields.csv")
    return

#Generate Parameters data as CSV
def getParameters(resourceName,ID,QuicksightResource):
    try:
        #Get the Parameters if ParameterDeclarations length is greater than 0
        if len(QuicksightResource["Definition"]["ParameterDeclarations"])>0:
            dataFilePath=path+resourceName+"Parameters"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_parameters.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Parameter_Type","Parameter_Value_Type","Parameter_Name","Parameter_Static_Default_Value",resourceName+"_ID"])
            for Parameter in QuicksightResource["Definition"]["ParameterDeclarations"]:
                #Get first key name
                ParameterDeclaration=list(Parameter.keys())[0]
                ParameterType=ParameterDeclaration.split("ParameterDeclaration")[0]
                if ParameterDeclaration!="DateTimeParameterDeclaration":
                    ParameterValueType=Parameter[ParameterDeclaration]["ParameterValueType"]
                else:
                    ParameterValueType=Parameter[ParameterDeclaration]["TimeGranularity"]
                ParameterName=Parameter[ParameterDeclaration]["Name"]
                #Check if DefaultValues is present and StaticValues is present
                if "DefaultValues" in Parameter[ParameterDeclaration] and "StaticValues" in Parameter[ParameterDeclaration]["DefaultValues"]:
                    ParameterDefaultValue=','.join(str(staicValue) for staicValue in Parameter[ParameterDeclaration]["DefaultValues"]["StaticValues"])
                else:
                    ParameterDefaultValue=None
                csvWriter.writerow([ParameterType,ParameterValueType,ParameterName,ParameterDefaultValue,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile, DataLineageBucket, resourceName+"Parameters"+"/"+resourceName+"_"+ID+"_parameters.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_parameters.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" Parameters",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" Parameters",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_parameters.csv")
    return

#Generate Parameter Control data as CSV
def getParameterControls(resourceName,ID,SheetID,Sheet):
    try:
        #Get the Parameter Controls if ParameterControls length is greater than 0
        if len(Sheet["ParameterControls"])>0:
            dataFilePath=path+resourceName+"SheetParameterControls"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_"+SheetID+"_parametercontrols.csv")
            #Write to CSV file
            csvFile = open(dataFile, "a")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Parameter_Control_ID","Parameter_Control_Name","Parameter_Control_Type","Parameter_Control_Source","Parameter_Control_Select_Type","Parameter_Control_SheetID",resourceName+"_ID"])
            for ParameterControl in Sheet["ParameterControls"]:
                ParameterControlType=list(ParameterControl.keys())[0]
                ParameterControlID=ParameterControl[ParameterControlType]["ParameterControlId"]
                ParameterControlName=ParameterControl[ParameterControlType]["Title"]
                #Check if SourceParameterName is present
                if "SourceParameterName" in ParameterControl[ParameterControlType]:
                    ParameterControlSource=ParameterControl[ParameterControlType]["SourceParameterName"]
                else:
                    ParameterControlSource=None
                #Check if ParameterControlType is "List" or "Dropdown"
                if ParameterControlType=="List" or ParameterControlType=="Dropdown":
                    ParameterControlSelectType=ParameterControl[ParameterControlType]["Type"]
                else:
                    ParameterControlSelectType="Other Control"
                #Write to CSV file
                csvWriter.writerow([ParameterControlID,ParameterControlName,ParameterControlType,ParameterControlSource,ParameterControlSelectType,SheetID,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(path+resourceName+"SheetParameterControls/"+resourceName+"_"+ID+"_"+SheetID+"_parametercontrols.csv",DataLineageBucket,resourceName+"SheetParameterControls"+"/"+resourceName+"_"+ID+"_"+SheetID+"_parametercontrols.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_"+SheetID+"_parametercontrols.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" ParameterControls",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" ParameterControls",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_"+SheetID+"_parametercontrols.csv")
    return

#Generate Filter Control data as CSV
def getFilterControls(resourceName,ID,SheetID,Sheet):
    try:
        #Get the Filter Controls if FilterControls length is greater than 0
        if len(Sheet["FilterControls"])>0:
            dataFilePath=path+resourceName+"SheetFilterControls"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_"+SheetID+"_filtercontrols.csv")
            #Write to CSV file
            csvFile = open(dataFile, "a")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Filter_Control_ID","Filter_Control_Name","Filter_Control_Type","Filter_Control_Source_ID","Filter_Control_Select_Type","Filter_Control_SheetID",resourceName+"_ID"])
            for FilterControl in Sheet["FilterControls"]:
                FilterControlType=list(FilterControl.keys())[0]
                FilterControlID=FilterControl[FilterControlType]["FilterControlId"]
                FilterControlName=FilterControl[FilterControlType]["Title"]
                #Check if SourceFilterId is present
                if "SourceFilterId" in FilterControl[FilterControlType]:
                    FilterControlSourceID=FilterControl[FilterControlType]["SourceFilterId"]
                else:
                    FilterControlSourceID=None
                #Check if FilterControlType is "List" or "Dropdown"
                if FilterControlType=="List" or FilterControlType=="Dropdown":
                    FilterControlSelectType=FilterControl[FilterControlType]["Type"]
                else:
                    FilterControlSelectType="Other Control"
                #Write to CSV file
                csvWriter.writerow([FilterControlID,FilterControlName,FilterControlType,FilterControlSourceID,FilterControlSelectType,SheetID,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(path+resourceName+"SheetFilterControls/"+resourceName+"_"+ID+"_"+SheetID+"_filtercontrols.csv",DataLineageBucket,resourceName+"SheetFilterControls"+"/"+resourceName+"_"+ID+"_"+SheetID+"_filtercontrols.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_"+SheetID+"_filtercontrols.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" SheetFiltercontrols",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" SheetFiltercontrols",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_"+SheetID+"_filtercontrols.csv")
    return

#Write Visuals data to CSV
def writeVisuals(csvWriter,field,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID):
    try:
        #Check if field is dict
        if type(next(iter((field.items())))[1])==dict:
            #Get first key name
            VisualFieldType=list(field.keys())[0]
            #Check if VisualFieldType is not "CalculatedMeasureField"
            if VisualFieldType!="CalculatedMeasureField":
                if "FieldId" in field[VisualFieldType]:
                    VisualFieldID=field[VisualFieldType]["FieldId"]
                else:
                    VisualFieldID=None
                if "Column" in field[VisualFieldType]:
                    if "ColumnName" in field[VisualFieldType]["Column"]:
                        VisualFieldName=field[VisualFieldType]["Column"]["ColumnName"]
                    else:
                        VisualFieldName=None
                    if "DataSetIdentifier" in field[VisualFieldType]["Column"]:
                        VisualFieldDataSetName=field[VisualFieldType]["Column"]["DataSetIdentifier"]
                    else:
                        VisualFieldDataSetName=None
                else:
                    VisualFieldName=None
                    VisualFieldDataSetName=None
                #Write to CSV file
                csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
        else:
            VisualFieldType=None
            if "FieldId" in field:
                VisualFieldID=field["FieldId"]
            else:
                VisualFieldID=None
            if "Column" in field:
                if "ColumnName" in field["Column"]:
                    VisualFieldName=field["Column"]["ColumnName"]
                else:
                    VisualFieldName=None
                if "DataSetIdentifier" in field["Column"]:
                    VisualFieldDataSetName=field["Column"]["DataSetIdentifier"]
                else:
                    VisualFieldDataSetName=None
            else:
                VisualFieldName=None
                VisualFieldDataSetName=None
            #Write to CSV file
            csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_"+SheetID+"_"+VisualID+"_visuals.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+"_"+ID+"_"+SheetID+"_"+VisualID+" SheetVisuals",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" SheetVisuals",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_"+SheetID+"_"+VisualID+"_visuals.csv")
    return

#Generate Visuals data as CSV
def getVisuals(resourceName,ID,SheetID,Sheet):
    try:
        #Get the Visuals if Visuals length is greater than 0
        if len(Sheet["Visuals"])>0:
            dataFilePath=path+resourceName+"SheetVisuals"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_"+SheetID+"_visuals.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Visual_Type","Visual_ID","Visual_Title","Visual_Title_Visibility","Visual_Field_Name","Visual_Field_Type","Visual_Field_ID","Visual_Field_DataSet_Name","Visual_SheetID",resourceName+"_ID"])
            VisualFieldID=None
            for Visual in Sheet["Visuals"]:
                        #Get first key name
                        VisualType=list(Visual.keys())[0]
                        VisualID=Visual[VisualType]["VisualId"]
                        #Check if Title key is present in Visual[VisualType]
                        if "Title" in Visual[VisualType]:
                            #Check if FormatText key is present in Visual[VisualType]["Title"]
                            if "FormatText" in Visual[VisualType]["Title"]:
                                #Check if PlainText key is present in Visual[VisualType]["Title"]["FormatText"]
                                if "PlainText" in Visual[VisualType]["Title"]["FormatText"]:
                                    VisualTitle=Visual[VisualType]["Title"]["FormatText"]["PlainText"]
                                else:
                                    VisualTitle=None
                            else:
                                VisualTitle=None
                            #Check if Visibility key is present in Visual[VisualType]["Title"]
                            if "Visibility" in Visual[VisualType]["Title"]:
                                VisualTitleVisibility=Visual[VisualType]["Title"]["Visibility"]
                            else:
                                VisualTitleVisibility=None
                        #Check if VisualType is "TableVisual"
                        if VisualType=="TableVisual":
                            #Check if TableAggregatedFieldWells key is present in FieldWells
                            if "TableAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through GroupBy if GroupBy is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableAggregatedFieldWells"]["GroupBy"])>0:
                                    for GroupByField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableAggregatedFieldWells"]["GroupBy"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,GroupByField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Iterate through Values if Values is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableAggregatedFieldWells"]["Values"])>0:
                                    for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableAggregatedFieldWells"]["Values"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if TableUnaggregatedFieldWells key is present in FieldWells
                            if "TableUnaggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through Values if Values is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableUnaggregatedFieldWells"]["Values"])>0:
                                    for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TableUnaggregatedFieldWells"]["Values"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is "PivotTableVisual"
                        if VisualType=="PivotTableVisual":
                            #Check if PivotTableAggregatedFieldWells key is present in FieldWells
                            if "PivotTableAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through Rows if Rows is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Rows"])>0:
                                    for RowsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Rows"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,RowsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Iterate through Columns if Columns is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Columns"])>0:
                                    for ColumnsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Columns"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ColumnsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Iterate through Values if Values is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Values"])>0:
                                    for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableAggregatedFieldWells"]["Values"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if PivotTableUnaggregatedFieldWells key is present in FieldWells
                            if "PivotTableUnaggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through Values if Values is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableUnaggregatedFieldWells"]["Values"])>0:
                                    for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PivotTableUnaggregatedFieldWells"]["Values"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is "BarChartVisual"
                        if VisualType=="BarChartVisual":
                            #Check if BarChartAggregatedFieldWells key is present in FieldWells
                            if "BarChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Category key is present in BarChartAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Values key is present in BarChartAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Colors key is present in BarChartAggregatedFieldWells
                                if "Colors" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]:
                                    #Iterate through Colors if Colors is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Colors"])>0:
                                        for ColorsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["Colors"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if SmallMultiples key is present in BarChartAggregatedFieldWells
                                if "SmallMultiples" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]:
                                    #Iterate through SmallMultiples if SmallMultiples is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["SmallMultiples"])>0:
                                        for SmallMultiplesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BarChartAggregatedFieldWells"]["SmallMultiples"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SmallMultiplesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is "KPIVisual"
                        if VisualType=="KPIVisual":
                            #Check if Values key is present in KPIVisual
                            if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through Values if Values is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["Values"])>0:
                                    for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["Values"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if TargetValues key is present in KPIVisual
                            if "TargetValues" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through TargetValues if TargetValues is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TargetValues"])>0:
                                    for TargetValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TargetValues"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,TargetValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if TrendGroups key is present in KPIVisual
                            if "TrendGroups" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through TrendGroups if TrendGroups is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TrendGroups"])>0:
                                    for TrendGroupsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TrendGroups"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,TrendGroupsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is PieChartVisual
                        if VisualType=="PieChartVisual":
                            #Check if PieChartAggregatedFieldWells key is present in FieldWells
                            if "PieChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in PieChartAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Category key is present in PieChartAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if SmallMultiples key is present in PieChartAggregatedFieldWells
                                if "SmallMultiples" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]:
                                    #Iterate through SmallMultiples if SmallMultiples is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["SmallMultiples"])>0:
                                        for SmallMultiplesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["PieChartAggregatedFieldWells"]["SmallMultiples"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SmallMultiplesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is GaugeChartVisual
                        if VisualType=="GaugeChartVisual":
                            #Check if Value key is present in GaugeChartVisual
                            if "Value" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through Value if Value is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["Value"])>0:
                                    for ValueField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["Value"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,ValueField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if TargetValues key is present in GaugeChartVisual
                            if "TargetValues" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Iterate through TargetValues if TargetValues is not empty
                                if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TargetValues"])>0:
                                    for TargetValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TargetValues"]:
                                        #Call writeVisuals function
                                        writeVisuals(csvWriter,TargetValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is RadarChartVisual
                        if VisualType=="RadarChartVisual":
                            #Check if RadarChartAggregatedFieldWells key is present in FieldWells
                            if "RadarChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in RadarChartAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Category key is present in RadarChartAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Color key is present in RadarChartAggregatedFieldWells
                                if "Color" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]:
                                    #Iterate through Color if Color is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Color"])>0:
                                        for ColorField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["RadarChartAggregatedFieldWells"]["Color"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is LineChartVisual
                        if VisualType=="LineChartVisual":
                            #Check if LineChartAggregatedFieldWells key is present in FieldWells
                            if "LineChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in LineChartAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Category key is present in LineChartAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Colors key is present in LineChartAggregatedFieldWells
                                if "Colors" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]:
                                    #Iterate through Colors if Colors is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Colors"])>0:
                                        for ColorsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["Colors"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if SmallMultiples key is present in LineChartAggregatedFieldWells
                                if "SmallMultiples" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]:
                                    #Iterate through SmallMultiples if SmallMultiples is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["SmallMultiples"])>0:
                                        for SmallMultiplesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["LineChartAggregatedFieldWells"]["SmallMultiples"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SmallMultiplesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is HeatMapVisual
                        if VisualType=="HeatMapVisual":
                            #Check if HeatMapAggregatedFieldWells key is present in FieldWells
                            if "HeatMapAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in HeatMapAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Rows key is present in HeatMapAggregatedFieldWells
                                if "Rows" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]:
                                    #Iterate through Rows if Rows is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Rows"])>0:
                                        for RowsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Rows"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,RowsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Columns key is present in HeatMapAggregatedFieldWell
                                if "Columns" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]:
                                    #Iterate through Columns if Columns is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Columns"])>0:
                                        for ColumnsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HeatMapAggregatedFieldWells"]["Columns"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColumnsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is TreeMapVisual
                        if VisualType=="TreeMapVisual":
                            #Check if TreeMapAggregatedFieldWells key is present in FieldWells
                            if "TreeMapAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Groups key is present in TreeMapAggregatedFieldWells
                                if "Groups" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]:
                                    #Iterate through Groups if Groups is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Groups"])>0:
                                        for GroupsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Groups"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,GroupsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Sizes key is present in TreeMapAggregatedFieldWells
                                if "Sizes" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]:
                                    #Iterate through Sizes if Sizes is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Sizes"])>0:
                                        for SizesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Sizes"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SizesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Colors key is present in TreeMapAggregatedFieldWells
                                if "Colors" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]:
                                    #Iterate through Colors if Colors is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Colors"])>0:
                                        for ColorsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["TreeMapAggregatedFieldWells"]["Colors"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is GeospatialMapVisual
                        if VisualType=="GeospatialMapVisual":
                            #Check if GeospatialMapAggregatedFieldWells key is present in FieldWells
                            if "GeospatialMapAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Geospatial key is present in GeospatialMapAggregatedFieldWells
                                if "Geospatial" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]:
                                    #Iterate through Geospatial if Geospatial is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Geospatial"])>0:
                                        for GeospatialField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Geospatial"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,GeospatialField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Colors key is present in GeospatialMapAggregatedFieldWells
                                if "Colors" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]:
                                    #Iterate through Colors if Colors is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Colors"])>0:
                                        for ColorsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Colors"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Values key is present in GeospatialMapAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["GeospatialMapAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is FilledMapVisual
                        if VisualType=="FilledMapVisual":
                            #Check if FilledMapAggregatedFieldWells key is present in FieldWells
                            if "FilledMapAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Geospatial key is present in FilledMapAggregatedFieldWells
                                if "Geospatial" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]:
                                    #Iterate through Geospatial if Geospatial is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]["Geospatial"])>0:
                                        for GeospatialField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]["Geospatial"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,GeospatialField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Values key is present in FilledMapAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FilledMapAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is FunnelChartVisual
                        if VisualType=="FunnelChartVisual":
                            #Check if FunnelAggregatedFieldWells key is present in FieldWells
                            if "FunnelAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in FunnelAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Category key is present in FunnelAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["FunnelAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is ScatterPlotVisual
                        if VisualType=="ScatterPlotVisual":
                            #Check if ScatterPlotCategoricallyAggregatedFieldWells key is present in FieldWells
                            if "ScatterPlotCategoricallyAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Category key is present in ScatterPlotCategoricallyAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if XAxis key is present in ScatterPlotCategoricallyAggregatedFieldWells
                                if "XAxis" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]:
                                    #Iterate through XAxis if XAxis is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["XAxis"])>0:
                                        for XAxisField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["XAxis"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,XAxisField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if YAxis key is present in ScatterPlotCategoricallyAggregatedFieldWells
                                if "YAxis" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]:
                                    #Iterate through YAxis if YAxis is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["YAxis"])>0:
                                        for YAxisField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["YAxis"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,YAxisField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Size key is present in ScatterPlotCategoricallyAggregatedFieldWells
                                if "Size" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]:
                                    #Iterate through Size if Size is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["Size"])>0:
                                        for SizeField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotCategoricallyAggregatedFieldWells"]["Size"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SizeField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                            #Check if ScatterPlotUnaggregatedFieldWells key is present in FieldWells
                            if "ScatterPlotUnaggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if XAxis key is present in ScatterPlotUnaggregatedFieldWells
                                if "XAxis" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]:
                                    #Iterate through XAxis if XAxis is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["XAxis"])>0:
                                        for XAxisField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["XAxis"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,XAxisField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if YAxis key is present in ScatterPlotUnaggregatedFieldWells
                                if "YAxis" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]:
                                    #Iterate through YAxis if YAxis is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["YAxis"])>0:
                                        for YAxisField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["YAxis"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,YAxisField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Size key is present in ScatterPlotUnaggregatedFieldWells
                                if "Size" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]:
                                    #Iterate through Size if Size is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["Size"])>0:
                                        for SizeField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ScatterPlotUnaggregatedFieldWells"]["Size"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SizeField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is ComboChartVisual
                        if VisualType=="ComboChartVisual":
                            #Check if ComboChartAggregatedFieldWells key is present in FieldWells
                            if "ComboChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Category key is present in ComboChartAggregatedFieldWells
                                if "Category" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]:
                                    #Iterate through Category if Category is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["Category"])>0:
                                        for CategoryField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["Category"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoryField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if BarValues key is present in ComboChartAggregatedFieldWells
                                if "BarValues" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]:
                                    #Iterate through BarValues if BarValues is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["BarValues"])>0:
                                        for BarValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["BarValues"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,BarValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Colors key is present in ComboChartAggregatedFieldWells
                                if "Colors" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]:
                                    #Iterate through Colors if Colors is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["Colors"])>0:
                                        for ColorsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["Colors"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ColorsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if LineValues key is present in ComboChartAggregatedFieldWells
                                if "LineValues" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]:
                                    #Iterate through LineValues if LineValues is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["LineValues"])>0:
                                        for LineValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["ComboChartAggregatedFieldWells"]["LineValues"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,LineValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is BoxPlotVisual
                        if VisualType=="BoxPlotVisual":
                            #Check if BoxPlotAggregatedFieldWells key is present in FieldWells
                            if "BoxPlotAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if GroupBy key is present in BoxPlotAggregatedFieldWells
                                if "GroupBy" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]:
                                    #Iterate through GroupBy if GroupBy is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]["GroupBy"])>0:
                                        for GroupByField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]["GroupBy"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,GroupByField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Values key is present in BoxPlotAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["BoxPlotAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is WaterfallVisual
                        if VisualType=="WaterfallVisual":
                            #Check if WaterfallChartAggregatedFieldWells key is present in FieldWells
                            if "WaterfallChartAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Categories key is present in WaterfallChartAggregatedFieldWells
                                if "Categories" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]:
                                    #Iterate through Categories if Categories is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Categories"])>0:
                                        for CategoriesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Categories"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,CategoriesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Values key is present in WaterfallChartAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Breakdowns key is present in WaterfallChartAggregatedFieldWells
                                if "Breakdowns" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]:
                                    #Iterate through Breakdowns if Breakdowns is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Breakdowns"])>0:
                                        for BreakdownsField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WaterfallChartAggregatedFieldWells"]["Breakdowns"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,BreakdownsField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is HistogramVisual
                        if VisualType=="HistogramVisual":
                            #Check if HistogramAggregatedFieldWells key is present in FieldWells
                            if "HistogramAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Values key is present in HistogramAggregatedFieldWells
                                if "Values" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HistogramAggregatedFieldWells"]:
                                    #Iterate through Values if Values is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HistogramAggregatedFieldWells"]["Values"])>0:
                                        for ValuesField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["HistogramAggregatedFieldWells"]["Values"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,ValuesField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is WordCloudVisual
                        if VisualType=="WordCloudVisual":
                            #Check if WordCloudAggregatedFieldWells key is present in FieldWells
                            if "WordCloudAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Size key is present in WordCloudAggregatedFieldWells
                                if "Size" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]:
                                    #Iterate through Size if Size is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]["Size"])>0:
                                        for SizeField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]["Size"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SizeField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if GroupBy key is present in WordCloudAggregatedFieldWells
                                if "GroupBy" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]:
                                    #Iterate through GroupBy if GroupBy is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]["GroupBy"])>0:
                                        for GroupByField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["WordCloudAggregatedFieldWells"]["GroupBy"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,GroupByField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is SankeyDiagramVisual
                        if VisualType=="SankeyDiagramVisual":
                            #Check if SankeyDiagramAggregatedFieldWells key is present in FieldWells
                            if "SankeyDiagramAggregatedFieldWells" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]:
                                #Check if Source key is present in SankeyDiagramAggregatedFieldWells
                                if "Source" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]:
                                    #Iterate through Source if Source is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Source"])>0:
                                        for SourceField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Source"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,SourceField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Destination key is present in SankeyDiagramAggregatedFieldWells
                                if "Destination" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]:
                                    #Iterate through Destination if Destination is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Destination"])>0:
                                        for DestinationField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Destination"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,DestinationField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                                #Check if Weight key is present in SankeyDiagramAggregatedFieldWells
                                if "Weight" in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]:
                                    #Iterate through Weight if Weight is not empty
                                    if len(Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Weight"])>0:
                                        for WeightField in Visual[VisualType]["ChartConfiguration"]["FieldWells"]["SankeyDiagramAggregatedFieldWells"]["Weight"]:
                                            #Call writeVisuals function
                                            writeVisuals(csvWriter,WeightField,VisualType,VisualID,VisualTitle,VisualTitleVisibility,resourceName,ID,SheetID)
                        #Check if VisualType is InsightVisual
                        if VisualType=="InsightVisual":
                            #Check if InsightConfiguration key is present in Visual
                            if "InsightConfiguration" in Visual[VisualType]:
                                #Check if Computations key is present in InsightConfiguration
                                if "Computations" in Visual[VisualType]["InsightConfiguration"]:
                                    #Iterate through Computations if Computations is not empty
                                    if len(Visual[VisualType]["InsightConfiguration"]["Computations"])>0:
                                        for Computation in Visual[VisualType]["InsightConfiguration"]["Computations"]:
                                            #Get first key name
                                            VisualFieldType=list(Computation.keys())[0]
                                            #Check if Category key is present in Computation
                                            if "Category" in Computation[VisualFieldType]:
                                                #Iterate through all keys in Category
                                                for CategoryField in Computation[VisualFieldType]["Category"]:
                                                    #Check if CategoryField is not "CalculatedMeasureField"
                                                    if CategoryField!="CalculatedMeasureField":
                                                        #Check if VisualFieldID key in CategoryField[VisualFieldType]
                                                        if "FieldId" in Computation[VisualFieldType]["Category"][CategoryField]:
                                                            VisualFieldID=Computation[VisualFieldType]["Category"][CategoryField]["FieldId"]
                                                        else:
                                                            VisualFieldID=None
                                                        #Check if Column in Computation[VisualFieldType]["Category"][CategoryField]
                                                        if "Column" in Computation[VisualFieldType]["Category"][CategoryField]:
                                                            #Check if ColumnName key is present in Column
                                                            if "ColumnName" in Computation[VisualFieldType]["Category"][CategoryField]["Column"]:
                                                                VisualFieldName=Computation[VisualFieldType]["Category"][CategoryField]["Column"]["ColumnName"]
                                                            else:
                                                                VisualFieldName=None
                                                            #Check if DataSetIdentifier key is present in Column
                                                            if "DataSetIdentifier" in Computation[VisualFieldType]["Category"][CategoryField]["Column"]:
                                                                VisualFieldDataSetName=Computation[VisualFieldType]["Category"][CategoryField]["Column"]["DataSetIdentifier"]
                                                            else:
                                                                VisualFieldDataSetName=None
                                                        else:
                                                            VisualFieldName=None
                                                            VisualFieldDataSetName=None
                                                        #Write to CSV file
                                                        csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
                                        #Check if Value key is present in Computation
                                        if "Value" in Computation[VisualFieldType]:
                                            #Iterate through all keys in Value if Value is not empty
                                            if len(Computation[VisualFieldType]["Value"])>0:
                                                for ValueField in Computation[VisualFieldType]["Value"]:
                                                    #Check if ValueField is not "CalculatedMeasureField"
                                                    if ValueField!="CalculatedMeasureField":
                                                        #Check if VisualFieldID key in ValueField[VisualFieldType]
                                                        if "FieldId" in Computation[VisualFieldType]["Value"][ValueField]:
                                                            VisualFieldID=Computation[VisualFieldType]["Value"][ValueField]["FieldId"]
                                                        else:
                                                            VisualFieldID=None
                                                        #Check if Column in Computation[VisualFieldType]["Value"][ValueField]
                                                        if "Column" in Computation[VisualFieldType]["Value"][ValueField]:
                                                            #Check if ColumnName key is present in Column
                                                            if "ColumnName" in Computation[VisualFieldType]["Value"][ValueField]["Column"]:
                                                                VisualFieldName=Computation[VisualFieldType]["Value"][ValueField]["Column"]["ColumnName"]
                                                            else:
                                                                VisualFieldName=None
                                                            #Check if DataSetIdentifier key is present in Column
                                                            if "DataSetIdentifier" in Computation[VisualFieldType]["Value"][ValueField]["Column"]:
                                                                VisualFieldDataSetName=Computation[VisualFieldType]["Value"][ValueField]["Column"]["DataSetIdentifier"]
                                                            else:
                                                                VisualFieldDataSetName=None
                                                        else:
                                                            VisualFieldName=None
                                                            VisualFieldDataSetName=None
                                                        #Write to CSV file
                                                        csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
                                        #Check if Time key is present in Computation
                                        if "Time" in Computation[VisualFieldType]:
                                            #Iterate through all keys in Time if Time is not empty
                                            if len(Computation[VisualFieldType]["Time"])>0:
                                                for TimeField in Computation[VisualFieldType]["Time"]:
                                                    #Check if TimeField is not "CalculatedMeasureField"
                                                    if TimeField!="CalculatedMeasureField":
                                                        #Check if VisualFieldID key in TimeField[VisualFieldType]
                                                        if "FieldId" in Computation[VisualFieldType]["Time"][TimeField]:
                                                            VisualFieldID=Computation[VisualFieldType]["Time"][TimeField]["FieldId"]
                                                        else:
                                                            VisualFieldID=None
                                                        #Check if Column in Computation[VisualFieldType]["Time"][TimeField]
                                                        if "Column" in Computation[VisualFieldType]["Time"][TimeField]:
                                                            #Check if ColumnName key is present in Column
                                                            if "ColumnName" in Computation[VisualFieldType]["Time"][TimeField]["Column"]:
                                                                VisualFieldName=Computation[VisualFieldType]["Time"][TimeField]["Column"]["ColumnName"]
                                                            else:
                                                                VisualFieldName=None
                                                            #Check if DataSetIdentifier key is present in Column
                                                            if "DataSetIdentifier" in Computation[VisualFieldType]["Time"][TimeField]["Column"]:
                                                                VisualFieldDataSetName=Computation[VisualFieldType]["Time"][TimeField]["Column"]["DataSetIdentifier"]
                                                            else:
                                                                VisualFieldDataSetName=None
                                                        else:
                                                            VisualFieldName=None
                                                            VisualFieldDataSetName=None
                                                        #Write to CSV file
                                                        csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
                                        #Check if FromValue key is present in Computation
                                        if "FromValue" in Computation[VisualFieldType]:
                                            #Iterate through all keys in FromValue if FromValue is not empty
                                            if len(Computation[VisualFieldType]["FromValue"])>0:
                                                for FromValueField in Computation[VisualFieldType]["FromValue"]:
                                                    #Check if FromValueField is not "CalculatedMeasureField"
                                                    if FromValueField!="CalculatedMeasureField":
                                                        #Check if VisualFieldID key in FromValueField[VisualFieldType]
                                                        if "FieldId" in Computation[VisualFieldType]["FromValue"][FromValueField]:
                                                            VisualFieldID=Computation[VisualFieldType]["FromValue"][FromValueField]["FieldId"]
                                                        else:
                                                            VisualFieldID=None
                                                        #Check if Column in Computation[VisualFieldType]["FromValue"][FromValueField]
                                                        if "Column" in Computation[VisualFieldType]["FromValue"][FromValueField]:
                                                            #Check if ColumnName key is present in Column
                                                            if "ColumnName" in Computation[VisualFieldType]["FromValue"][FromValueField]["Column"]:
                                                                VisualFieldName=Computation[VisualFieldType]["FromValue"][FromValueField]["Column"]["ColumnName"]
                                                            else:
                                                                VisualFieldName=None
                                                            #Check if DataSetIdentifier key is present in Column
                                                            if "DataSetIdentifier" in Computation[VisualFieldType]["FromValue"][FromValueField]["Column"]:
                                                                VisualFieldDataSetName=Computation[VisualFieldType]["FromValue"][FromValueField]["Column"]["DataSetIdentifier"]
                                                            else:
                                                                VisualFieldDataSetName=None
                                                        else:
                                                            VisualFieldName=None
                                                            VisualFieldDataSetName=None
                                                        #Write to CSV file
                                                        csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
                                        #Check if TargetValue key is present in Computation
                                        if "TargetValue" in Computation[VisualFieldType]:
                                            #Iterate through all keys in TargetValue if TargetValue is not empty
                                            if len(Computation[VisualFieldType]["TargetValue"])>0:
                                                for TargetValueField in Computation[VisualFieldType]["TargetValue"]:
                                                    #Check if TargetValueField is not "CalculatedMeasureField"
                                                    if TargetValueField!="CalculatedMeasureField":
                                                        #Check if VisualFieldID key in TargetValueField[VisualFieldType]
                                                        if "FieldId" in Computation[VisualFieldType]["TargetValue"][TargetValueField]:
                                                            VisualFieldID=Computation[VisualFieldType]["TargetValue"][TargetValueField]["FieldId"]
                                                        else:
                                                            VisualFieldID=None
                                                        #Check if Column in Computation[VisualFieldType]["TargetValue"][TargetValueField]
                                                        if "Column" in Computation[VisualFieldType]["TargetValue"][TargetValueField]:
                                                            #Check if ColumnName key is present in Column
                                                            if "ColumnName" in Computation[VisualFieldType]["TargetValue"][TargetValueField]["Column"]:
                                                                VisualFieldName=Computation[VisualFieldType]["TargetValue"][TargetValueField]["Column"]["ColumnName"]
                                                            else:
                                                                VisualFieldName=None
                                                            #Check if DataSetIdentifier key is present in Column
                                                            if "DataSetIdentifier" in Computation[VisualFieldType]["TargetValue"][TargetValueField]["Column"]:
                                                                VisualFieldDataSetName=Computation[VisualFieldType]["TargetValue"][TargetValueField]["Column"]["DataSetIdentifier"]
                                                            else:
                                                                VisualFieldDataSetName=None
                                                        else:
                                                            VisualFieldName=None
                                                            VisualFieldDataSetName=None
                                                        #Write to CSV file
                                                        csvWriter.writerow([VisualType,VisualID,VisualTitle,VisualTitleVisibility,VisualFieldName,VisualFieldType,VisualFieldID,VisualFieldDataSetName,SheetID,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(path+resourceName+"SheetVisuals/"+resourceName+"_"+ID+"_"+SheetID+"_visuals.csv",DataLineageBucket,resourceName+"SheetVisuals"+"/"+resourceName+"_"+ID+"_"+SheetID+"_visuals.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_"+SheetID+"_visuals.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" SheetVisuals",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" SheetVisuals",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_"+SheetID+"_visuals.csv")
    return

#Generate Sheets data as CSV
def getSheets(resourceName,ID,QuicksightResource):
    try:
        #Get the Sheets if SheetConfigurations length is greater than 0
        if len(QuicksightResource["Definition"]["Sheets"])>0:
            dataFilePath=path+resourceName+"Sheets"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_sheets.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Sheet_Name","Sheet_ID","Sheet_Type",resourceName+"_ID"])
            for Sheet in QuicksightResource["Definition"]["Sheets"]:
                    SheetName=Sheet["Name"]
                    SheetID=Sheet["SheetId"]
                    SheetType=Sheet["ContentType"]
                    csvWriter.writerow([SheetName,SheetID,SheetType,ID])
                    #Check if Sheet has "ParameterControls" key
                    if "ParameterControls" in Sheet:
                        #Invoke getParameterControls function to get Parameter Controls
                        getParameterControls(resourceName,ID,SheetID,Sheet)
                    #Check if Sheet has "FilterControls" key
                    if "FilterControls" in Sheet:
                        #Invoke getFilterControls function to get Filter Controls
                        getFilterControls(resourceName,ID,SheetID,Sheet)
                    #Check if Sheet has "Visuals" key
                    if "Visuals" in Sheet:
                        #Invoke getVisuals function to get Visuals
                        getVisuals(resourceName,ID,SheetID,Sheet)
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile,DataLineageBucket,resourceName+"Sheets"+"/"+resourceName+"_"+ID+"_sheets.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_sheets.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" Sheets",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" Sheets",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_sheets.csv")
    return

#Generate Filters data as CSV
def getFilters(resourceName,ID,QuicksightResource):
    try:
        #Get the Filter Groups if FilterGroups length is greater than 0
        if len(QuicksightResource["Definition"]["FilterGroups"])>0:
            dataFilePath=path+resourceName+"Filters"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_filters.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Filter_Group_ID","Filter_Status","Filter_DataSet_Scope","Filter_Type","Filter_ID","Filter_Column",
                                "Filter_Column_DataSet","Filter_Sheet_ID","Filter_Scope","Filter_Visual_ID",resourceName+"_ID"])
            for Filter in QuicksightResource["Definition"]["FilterGroups"]:
                    FilterGroupID=Filter["FilterGroupId"]
                    FilterStatus=Filter["Status"]
                    FilterDataSetScope=Filter["CrossDataset"]
                    #Get the Filters if Filters length is greater than 0
                    if len(Filter["Filters"])>0:
                        for FilterData in Filter["Filters"]:
                            FilterType=list(FilterData.keys())[0]
                            FilterID=FilterData[FilterType]["FilterId"]
                            #Check if Column is present 
                            if "Column" in FilterData[FilterType]:
                                #Check if ColumnName is present in Column
                                if "ColumnName" in FilterData[FilterType]["Column"]:
                                    FilterColumn=FilterData[FilterType]["Column"]["ColumnName"]
                                else:
                                    FilterColumn=None
                                #Check if DataSetIdentifier is present in Column
                                if "DataSetIdentifier" in FilterData[FilterType]["Column"]:
                                    FilterColumnDataSet=FilterData[FilterType]["Column"]["DataSetIdentifier"]
                                else:
                                    FilterColumnDataSet=None
                            #Get Filter Visual IDs if SheetVisualScopingConfigurations length is greater than 0
                            if len(Filter["ScopeConfiguration"]["SelectedSheets"]["SheetVisualScopingConfigurations"])>0:
                                for ScopingConfiguration in Filter["ScopeConfiguration"]["SelectedSheets"]["SheetVisualScopingConfigurations"]:
                                    FilterSheetID=ScopingConfiguration["SheetId"]
                                    FilterScope=ScopingConfiguration["Scope"]
                                    #Get Visual IDs if FilterScope is "SELECTED_VISUALS"
                                    if FilterScope=="SELECTED_VISUALS":
                                        #Get Visual IDs if VisualIds length is greater than 0
                                        if len(ScopingConfiguration["VisualIds"])>0:
                                            for VisualID in ScopingConfiguration["VisualIds"]:
                                                FilterVisualID=VisualID
                                                #Write to CSV file
                                                csvWriter.writerow([FilterGroupID,FilterStatus,FilterDataSetScope,FilterType,FilterID,FilterColumn,
                                                        FilterColumnDataSet,FilterSheetID,FilterScope,FilterVisualID,ID])
                                    else:
                                        FilterVisualID="All Visuals in Sheet"
                                        #Write to CSV file
                                        csvWriter.writerow([FilterGroupID,FilterStatus,FilterDataSetScope,FilterType,FilterID,FilterColumn,
                                                        FilterColumnDataSet,FilterSheetID,FilterScope,FilterVisualID,ID])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile,DataLineageBucket,resourceName+"Filters"+"/"+resourceName+"_"+ID+"_filters.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_filters.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" Filters",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" Filters",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_filters.csv")
    return

#Generate Resource Errors as CSV
def getResourceErrors(resourceName,ID,QuicksightResource):
    try:
        #Get the resourceErrors if Errors length is greater than 0
        if len(QuicksightResource["Errors"])>0:
            dataFilePath=path+resourceName+"Errors"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,resourceName+"_"+ID+"_errors.csv")
            #Write to CSV file
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow([resourceName+"_ID",resourceName+"_Name","Error_Type","Error_Message","Error_Path"])
            for Error in QuicksightResource["Errors"]:
                ErrorType=Error["Type"]
                ErrorMessage=Error["Message"]
                #Check if ViolatedEntities is present in Error
                if "ViolatedEntities" in Error:
                    #Iterate over ViolatedEntities
                    for ViolatedEntity in Error["ViolatedEntities"]:
                        #Check if Path is present in ViolatedEntity
                        if "Path" in ViolatedEntity:
                            ErrorPath=ViolatedEntity["Path"]
                        else:
                            ErrorPath=None
                        #Write to CSV file
                        csvWriter.writerow([ID,resourceName,ErrorType,ErrorMessage,ErrorPath])
            csvFile.close()
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"_"+ID+"_definitionerrors.csv")
        #Open a CSV file to write the exception
        print(["Exception in "+resourceName+" "+ID+" Errors",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in "+resourceName+" "+ID+" Errors",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"_"+ID+"_definitionerrors.csv")

#Describe QuickSight Analysis or Dashboard
def describeResource(ResourceID,resourceName):
    try:
        dataFilePath=path+resourceName+"Description"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,resourceName+"_"+ResourceID+"_description.csv")
        #Write to CSV file
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        #Check if resourceName is Analysis or Dashboard
        if resourceName=="Analysis":
            #Describe the Analysis
            QuicksightResource=quicksight.describe_analysis(AwsAccountId=awsAccountId,AnalysisId=ResourceID)
            csvWriter.writerow([resourceName+"_ID",resourceName+"_Name",resourceName+"_"+"Created_Time",resourceName+"_"+"Last_Updated_Time","Theme","ResourceStatus"])
            CreatedTime=QuicksightResource[resourceName]["CreatedTime"].isoformat(timespec='seconds')
            LastUpdatedTime=QuicksightResource[resourceName]["LastUpdatedTime"].isoformat(timespec='seconds')
            if "Name" in QuicksightResource[resourceName]:
                Name=QuicksightResource[resourceName]["Name"]
            else:
                Name=None
            if "ThemeArn" in QuicksightResource:
                ResourceTheme=QuicksightResource["ThemeArn"].split("/")[-1]
            else:
                ResourceTheme=None
            if "Status" in QuicksightResource:
                ResourceStatus=QuicksightResource["Status"]
            else:
                ResourceStatus=None
            csvWriter.writerow([ResourceID,Name,CreatedTime,LastUpdatedTime,ResourceTheme,ResourceStatus])
        if resourceName=="Dashboard":
            #Describe the Dashboard
            QuicksightResource=quicksight.describe_dashboard(AwsAccountId=awsAccountId,DashboardId=ResourceID)
            csvWriter.writerow([resourceName+"_ID",resourceName+"_Name",resourceName+"_"+"Created_Time",resourceName+"_"+"Last_Updated_Time",resourceName+"_"+"Last_Published_Time",resourceName+"_"+"Version_Created_Time",resourceName+"_"+"Version_Description",resourceName+"_"+"Version_Source_Entity_Type",resourceName+"_"+"Version_Source_Entity_ID",resourceName+"_"+"Version_Number",resourceName+"_"+"Version_Theme",resourceName+"_"+"Version_Status"])
            CreatedTime=QuicksightResource[resourceName]["CreatedTime"].isoformat(timespec='seconds')
            LastUpdatedTime=QuicksightResource[resourceName]["LastUpdatedTime"].isoformat(timespec='seconds')
            LastPublishedTime=QuicksightResource[resourceName]["LastPublishedTime"].isoformat(timespec='seconds')
            if "Name" in QuicksightResource[resourceName]:
                Name=QuicksightResource[resourceName]["Name"]
            else:
                Name=None
            #Check if Version is present in Dashboard
            if "Version" in QuicksightResource[resourceName]:
                if "VersionCreatedTime" in QuicksightResource[resourceName]["Version"]:
                    VersionCreatedTime=QuicksightResource[resourceName]["Version"]["VersionCreatedTime"].isoformat(timespec='seconds')
                else:
                    VersionCreatedTime=None
                if "VersionDescription" in QuicksightResource[resourceName]["Version"]:
                    VersionDescription=QuicksightResource[resourceName]["Version"]["VersionDescription"]
                else:
                    VersionDescription=None
                if "VersionSourceEntityArn" in QuicksightResource[resourceName]["Version"]:
                    VersionSourceEntityType=QuicksightResource[resourceName]["Version"]["VersionSourceEntityArn"].rsplit(":",1)[1].rsplit("/",1)[0]
                    VersionSourceEntityID=QuicksightResource[resourceName]["Version"]["VersionSourceEntityArn"].rsplit("/",1)[1]
                else:
                    VersionSourceEntityType=None
                    VersionSourceEntityID=None
                if "VersionNumber" in QuicksightResource[resourceName]["Version"]:
                    VersionNumber=QuicksightResource[resourceName]["Version"]["VersionNumber"]
                else:
                    VersionNumber=None
                if "ThemeArn" in QuicksightResource[resourceName]["Version"]:
                    ResourceTheme=QuicksightResource[resourceName]["Version"]["ThemeArn"].split("/")[-1]
                else:
                    ResourceTheme=None
                if "Status" in QuicksightResource[resourceName]["Version"]:
                    ResourceStatus=QuicksightResource[resourceName]["Version"]["Status"]
                else:
                    ResourceStatus=None
            else:
                VersionCreatedTime=None
                VersionDescription=None
                VersionSourceEntityType=None
                VersionSourceEntityID=None
                VersionNumber=None
            csvWriter.writerow([ResourceID,Name,CreatedTime,LastUpdatedTime,LastPublishedTime,VersionCreatedTime,VersionDescription,VersionSourceEntityType,VersionSourceEntityID,VersionNumber,ResourceTheme,ResourceStatus])
        if resourceName=="Template":
            #Describe the Template
            QuicksightResource=quicksight.describe_template(AwsAccountId=awsAccountId,TemplateId=ResourceID)
            csvWriter.writerow([resourceName+"_ID",resourceName+"_Name",resourceName+"_"+"Created_Time",resourceName+"_"+"Last_Updated_Time",resourceName+"_"+"Version_Created_Time",resourceName+"_"+"Version_Description",resourceName+"_"+"Version_Source_Entity_Type",resourceName+"_"+"Version_Source_Entity_ID",resourceName+"_"+"Version_Number",resourceName+"_"+"Version_Status",resourceName+"_"+"Version_Theme"])
            if "Name" in QuicksightResource[resourceName]:
                Name=QuicksightResource[resourceName]["Name"]
            else:
                Name=None
            CreatedTime=QuicksightResource[resourceName]["CreatedTime"].isoformat(timespec='seconds')
            LastUpdatedTime=QuicksightResource[resourceName]["LastUpdatedTime"].isoformat(timespec='seconds')
            #Check if Version is present in Dashboard
            if "Version" in QuicksightResource[resourceName]:
                if "CreatedTime" in QuicksightResource[resourceName]["Version"]:
                    VersionCreatedTime=QuicksightResource[resourceName]["Version"]["CreatedTime"].isoformat(timespec='seconds')
                else:
                    VersionCreatedTime=None
                if "Description" in QuicksightResource[resourceName]["Version"]:
                    VersionDescription=QuicksightResource[resourceName]["Version"]["Description"]
                else:
                    VersionDescription=None
                if "SourceEntityArn" in QuicksightResource[resourceName]["Version"]:
                    VersionSourceEntityType=QuicksightResource[resourceName]["Version"]["SourceEntityArn"].rsplit(":",1)[1].rsplit("/",1)[0]
                    VersionSourceEntityID=QuicksightResource[resourceName]["Version"]["SourceEntityArn"].rsplit("/",1)[1]
                else:
                    VersionSourceEntityType=None
                    VersionSourceEntityID=None
                if "VersionNumber" in QuicksightResource[resourceName]["Version"]:
                    VersionNumber=QuicksightResource[resourceName]["Version"]["VersionNumber"]
                else:
                    VersionNumber=None
                if "Status" in QuicksightResource[resourceName]["Version"]:
                    VersionStatus=QuicksightResource[resourceName]["Version"]["Status"]
                else:
                    VersionStatus=None
                if "ThemeArn" in QuicksightResource[resourceName]["Version"]:
                    VesrionTheme=QuicksightResource[resourceName]["Version"]["ThemeArn"].split("/")[-1]
                else:
                    VesrionTheme=None
            else:
                VersionCreatedTime=None
                VersionDescription=None
                VersionSourceEntityType=None
                VersionSourceEntityID=None
                VersionNumber=None
                VersionStatus=None
                VesrionTheme=None
            csvWriter.writerow([ResourceID,Name,CreatedTime,LastUpdatedTime,VersionCreatedTime,VersionDescription,VersionSourceEntityType,VersionSourceEntityID,VersionNumber,VersionStatus,VesrionTheme])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile,DataLineageBucket,resourceName+"Description/"+resourceName+"_"+ResourceID+"_description.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_describe"+resourceName+"_"+ResourceID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in describe"+resourceName+" "+ResourceID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in describe"+resourceName+"_"+ResourceID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_describe"+resourceName+"_"+ResourceID+".csv")

#Describe QuickSight Resource Permissions
def describeResourcePermissions(ResourceID,resourceName):
    try:
        dataFilePath=path+resourceName+"Permissions"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,resourceName+"_"+ResourceID+"_permissions.csv")
        #Write to CSV file
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        csvWriter.writerow([resourceName+"_ID","Principal_Name","Principal_Type","Permission_Type"])
        #Check if resourceName is Analysis or Dashboard
        if resourceName=="Analysis":
            #Describe the Analysis Permissions
            QuicksightResource=quicksight.describe_analysis_permissions(AwsAccountId=awsAccountId,AnalysisId=ResourceID)
        elif resourceName=="Dashboard":
            #Describe the Dashboard Permissions
            QuicksightResource=quicksight.describe_dashboard_permissions(AwsAccountId=awsAccountId,DashboardId=ResourceID)
        elif resourceName=="DataSet":
            #Describe the DataSet Permissions
            QuicksightResource=quicksight.describe_data_set_permissions(AwsAccountId=awsAccountId,DataSetId=ResourceID)
        elif resourceName=="DataSource":
            #Describe the DataSource Permissions
            QuicksightResource=quicksight.describe_data_source_permissions(AwsAccountId=awsAccountId,DataSourceId=ResourceID)
        elif resourceName=="Folder":
            #Describe the Folder Permissions
            QuicksightResource=quicksight.describe_folder_resolved_permissions(AwsAccountId=awsAccountId,FolderId=ResourceID)
        elif resourceName=="Template":
            #Describe the Template Permissions
            QuicksightResource=quicksight.describe_template_permissions(AwsAccountId=awsAccountId,TemplateId=ResourceID)
        else:
            #If resourceName not recognized
            return
        #Iterate through the QuicksightResource["Permissions"] if Permissions in QuicksightResource
        if "Permissions" in QuicksightResource:
            #Check if length of Permissions is greater than 0
            if len(QuicksightResource["Permissions"])>0:
                PermissionType=None
                for permission in QuicksightResource["Permissions"]:
                    #Check PermissionType of Principal
                    if "quicksight:DeleteDashboard" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    elif "quicksight:DescribeAnalysis" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    elif "quicksight:DeleteFolder" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    elif "quicksight:DeleteFolderMembership" in permission["Actions"] and "quicksight:DeleteFolder" not in permission["Actions"]:
                        PermissionType="Contributor"
                    elif "quicksight:DeleteDataSource" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    elif "quicksight:DeleteDataSet" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    elif "quicksight:DeleteTemplate" in permission["Actions"]:
                        PermissionType="Owner/Co-Owner"
                    else:
                        PermissionType="Viewer"
                    if "user/" in permission["Principal"]:
                        PrincipalType="User"
                        PrincipalName=permission["Principal"].rsplit("user/",1)[1]
                    elif "group/" in permission["Principal"]:
                        PrincipalType="Group"
                        PrincipalName=permission["Principal"].rsplit("group/",1)[1]
                    elif "namespace/" in permission["Principal"]:
                        PrincipalType="Namespace"
                        PrincipalName=permission["Principal"].rsplit("namespace/",1)[1]
                    else:
                        PrincipalType="Unknown"
                        PrincipalName=permission["Principal"]
                    csvWriter.writerow([ResourceID,PrincipalName,PrincipalType,PermissionType])
        if "LinkSharingConfiguration" in QuicksightResource:
            #Check if length of Permissions is greater than 0
            if len(QuicksightResource["LinkSharingConfiguration"]["Permissions"])>0:
                for permission in QuicksightResource["LinkSharingConfiguration"]["Permissions"]:
                    PermissionType="Viewer"
                    if "publicAnonymousUser/" in permission["Principal"]:
                        PrincipalType="Public"
                        PrincipalName=permission["Principal"].rsplit("publicAnonymousUser/",1)[1]
                    elif "namespace/" in permission["Principal"]:
                        PrincipalType="Namespace"
                        PrincipalName=permission["Principal"].rsplit("namespace/",1)[1]
                    else:
                        PrincipalType="Unknown"
                        PrincipalName=permission["Principal"]
                    csvWriter.writerow([ResourceID,PrincipalName,PrincipalType,PermissionType])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile,DataLineageBucket,resourceName+"Permissions/"+resourceName+"_"+ResourceID+"_permissions.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_"+resourceName+"Permissions_"+ResourceID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in describe"+resourceName+"Permissions_"+ResourceID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in describe"+resourceName+"Permissions_"+ResourceID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_"+resourceName+"Permissions_"+ResourceID+".csv")

#Describe QuickSight Analysis Definition
def describeAnalysisDefinition(AnalysisID):
    try:
        #Describe the Analysis
        Analysis=quicksight.describe_analysis_definition(AwsAccountId=awsAccountId,AnalysisId=AnalysisID)
        resourceName="Analysis"
        ID=Analysis["AnalysisId"]
        #Check if Analysis[ResourceStatus] is "CREATION_SUCCESSFUL"
        if Analysis["ResourceStatus"]=="CREATION_SUCCESSFUL":
            #Get the Analysis/Dashboard Name
            #getAnalysisDashboardName(resourceName,ID,Analysis)
            #Check if Analysis["Definition"]["DataSetIdentifierDeclarations"] key is present
            if "DataSetIdentifierDeclarations" in Analysis["Definition"]:
                #Get the DataSets
                getResourceDataSets(resourceName,ID,Analysis)
            #Check if Analysis["Definition"]["CalculatedFields"] key is present
            if "CalculatedFields" in Analysis["Definition"]:
                #Get the Calculated Fields
                getCalculatedFields(resourceName,ID,Analysis)
            #Check if Analysis["Definition"]["ParameterDeclarations"] key is present
            if "ParameterDeclarations" in Analysis["Definition"]:
                #Get the Parameters
                getParameters(resourceName,ID,Analysis)
            #Check if Analysis["Definition"]["Sheets"] key is present
            if "Sheets" in Analysis["Definition"]:
                #Get the Sheets
                getSheets(resourceName,ID,Analysis)
            #Check if Analysis["Definition"]["FilterGroups"] key is present
            if "FilterGroups" in Analysis["Definition"]:
                #Get the Filters
                getFilters(resourceName,ID,Analysis)
            #Check if Analysis["Errors"] key is present
            if "Errors" in Analysis:
                #Get the resourceErrors
                getResourceErrors(resourceName,ID,Analysis)
        else:
            #Check if Analysis["Errors"] key is present
            if "Errors" in Analysis:
                #Get the resourceErrors
                getResourceErrors(resourceName,ID, Analysis)
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_describeAnalysisDefinition_"+AnalysisID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in describeAnalysisDefinition"+" "+AnalysisID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in describeAnalysisDefinition"+" "+AnalysisID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_describeAnalysisDefinition_"+AnalysisID+".csv")
    return

#Describe QuickSight Dashboard Definition
def describeDashboardDefinition(DashboardID):
    try:
        #Describe the Dashboard
        Dashboard=quicksight.describe_dashboard_definition(AwsAccountId=awsAccountId,DashboardId=DashboardID)
        resourceName="Dashboard"
        ID=Dashboard["DashboardId"]
        #Check if Dashboard[ResourceStatus] is "CREATION_SUCCESSFUL"
        if Dashboard["ResourceStatus"]=="CREATION_SUCCESSFUL":
            #Get the Dashboard Name
            #getAnalysisDashboardName(resourceName,ID,Dashboard)
            #Check if Dashboard["Definition"]["DataSetIdentifierDeclarations"] key is present
            if "DataSetIdentifierDeclarations" in Dashboard["Definition"]:
                #Get the DataSets
                getResourceDataSets(resourceName,ID,Dashboard)
            #Check if Dashboard["Definition"]["CalculatedFields"] key is present
            if "CalculatedFields" in Dashboard["Definition"]:
                #Get the Calculated Fields
                getCalculatedFields(resourceName,ID,Dashboard)
            #Check if Dashboard["Definition"]["ParameterDeclarations"] key is present
            if "ParameterDeclarations" in Dashboard["Definition"]:
                #Get the Parameters
                getParameters(resourceName,ID,Dashboard)
            #Check if Dashboard["Definition"]["Sheets"] key is present
            if "Sheets" in Dashboard["Definition"]:
                #Get the Sheets
                getSheets(resourceName,ID,Dashboard)
            #Check if Dashboard["Definition"]["FilterGroups"] key is present
            if "FilterGroups" in Dashboard["Definition"]:
                #Get the Filters
                getFilters(resourceName,ID,Dashboard)
            #Check if Dashboard["Errors"] key is present
            if "Errors" in Dashboard:
                #Get the resourceErrors
                getResourceErrors(resourceName,ID,Dashboard)
        else:
            #Check if Dashboard["Errors"] key is present
            if "Errors" in Dashboard:
                #Get the resourceErrors
                getResourceErrors(resourceName,ID, Dashboard)
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_describeDashboardDefinition_"+DashboardID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in describeDashboardDefinition"+" "+DashboardID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in describeDashboardDefinition"+" "+DashboardID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_describeDashboardDefinition_"+DashboardID+".csv")

#Get DataSet Columns
def getDataSetColumns(DataSetID,OutPutColumns):
    try:
        dataFilePath=path+"DataSetsColumns"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,"DataSetColumns_"+DataSetID+".csv")
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        csvWriter.writerow(["DataSet_ID","DataSet_Column_Name","DataSet_Column_Type","DataSet_Column_Description"])
        for column in OutPutColumns:
            if "Name" in column:
                DataSet_Column_Name=column["Name"]
            else:
                DataSet_Column_Name=None
            if "Type" in column:
                DataSet_Column_Type=column["Type"]
            else:
                DataSet_Column_Type=None
            if "Description" in column:
                DataSet_Column_Description=column["Description"]
            else:
                DataSet_Column_Description=None
            csvWriter.writerow([DataSetID,DataSet_Column_Name,DataSet_Column_Type,DataSet_Column_Description])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile, DataLineageBucket, "DataSetsColumns/DataSetColumns_"+DataSetID+"_.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_getDataSetColumns_"+DataSetID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in getDataSetColumns"+" "+DataSetID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in getDataSetColumns"+" "+DataSetID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_getDataSetColumns_"+DataSetID+".csv")

#Describe QuickSight DataSet
def describeDataSet(DataSetID):
    try:
        DataSetDescription=quicksight.describe_data_set(AwsAccountId=awsAccountId,DataSetId=DataSetID)
        dataFilePath=path+"DataSets"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,"DataSet_"+DataSetID+".csv")
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        csvWriter.writerow(["DataSet_ID","DataSet_Name","DataSet_CLS_Enabled","DataSet_Creation_Time","DataSet_Last_Updated_Time","DataSet_Disable_UseAsDirectQuerySource","DataSet_UseAsImportedSource","DataSet_Import_Mode","DataSet_RLS_Status","DataSet_RLS_ARN","DataSet_RLS_Tags_Status","DataSet_SPICE_Capacity"])
        if "DataSet" in DataSetDescription:
            DataSet=DataSetDescription["DataSet"]
            DataSetID=DataSet["DataSetId"]
            DataSetName=DataSet["Name"]
            if "ColumnLevelPermissionRules" in DataSet:
                if len(DataSet["ColumnLevelPermissionRules"])>0:
                    DataSetCLSEnabled="True"
            else:
                DataSetCLSEnabled="False"
            DataSetCreationTime=DataSet["CreatedTime"].isoformat(timespec='seconds')
            DataSetLastUpdatedTime=DataSet["LastUpdatedTime"].isoformat(timespec='seconds')
            if "DataSetUsageConfiguration" in DataSet:
                if "DisableUseAsDirectQuerySource" in DataSet["DataSetUsageConfiguration"]:
                    DataSetDisableUseAsDirectQuerySource=str(DataSet["DataSetUsageConfiguration"]["DisableUseAsDirectQuerySource"])
                else:
                    DataSetDisableUseAsDirectQuerySource=None
                if "DisableUseAsImportedSource" in DataSet["DataSetUsageConfiguration"]:
                    DataSetUseAsImportedSource=str(DataSet["DataSetUsageConfiguration"]["DisableUseAsImportedSource"])
                else:
                    DataSetUseAsImportedSource=None
            else:
                DataSetDisableUseAsDirectQuerySource=None
                DataSetUseAsImportedSource=None
            DataSetImportMode=DataSet["ImportMode"]
            if "RowLevelPermissionDataSet" in DataSet:
                if "Arn" in DataSet["RowLevelPermissionDataSet"]:
                    DataSetRLSARN=DataSet["RowLevelPermissionDataSet"]["Arn"]
                else:
                    DataSetRLSARN=None
                if "Status" in DataSet["RowLevelPermissionDataSet"]:
                    DataSetRLSStatus=DataSet["RowLevelPermissionDataSet"]["Status"]
                else:
                    DataSetRLSStatus=None
            else:
                DataSetRLSARN=None
                DataSetRLSStatus=None
            DataSetSPICECapacity=DataSet["ConsumedSpiceCapacityInBytes"]
            csvWriter.writerow([DataSetID,DataSetName,DataSetCLSEnabled,DataSetCreationTime,DataSetLastUpdatedTime,DataSetDisableUseAsDirectQuerySource,DataSetUseAsImportedSource,DataSetImportMode,DataSetRLSStatus,DataSetRLSARN,DataSetRLSStatus,DataSetSPICECapacity])
            #Get DataSet Columns
            if "OutputColumns" in DataSet:
                if len(DataSet["OutputColumns"])>0:
                    getDataSetColumns(DataSetID,DataSet["OutputColumns"])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile, DataLineageBucket, "DataSets/DataSet_"+DataSetID+"_.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_describeDataSet_"+DataSetID+".csv")
        #Open a CSV file to write the exception
        #print(["Exception in describeDataSet_"+DataSetID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in describeDataSet_"+DataSetID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_describeDataSet_"+DataSetID+".csv")

#Generate QuickSight Datasources as CSV
def generateDataSources(DataSource):
    try:
        DataSourceID=DataSource["DataSourceId"]
        dataFilePaths=path+"DataSources"
        if not os.path.exists(dataFilePaths):
            os.mkdir(dataFilePaths)
        dataFile=os.path.join(dataFilePaths,"DataSource_"+DataSourceID+".csv")
        csvFile = open(dataFile, "w")
        csvWriter = csv.writer(csvFile)
        csvWriter.writerow(["Data_Source_ID","Data_Source_Name","Data_Source_Type","Data_Source_Status","Data_Source_Created_Time","Data_Source_Last_Updated_Time","Data_Source_Disable_SSL","Data_Source_Error_Message","Data_Source_Error_Type","Data_Source_VPC_ARN"])
        DataSourceName=DataSource["Name"]
        DataSourceType=DataSource["Type"]
        if "Status" in DataSource:
            DataSourceStatus=DataSource["Status"]
        else:
            DataSourceStatus=None
        if isinstance(DataSource["CreatedTime"], str):
            pass
        else:
            DataSource["CreatedTime"]=str(DataSource["CreatedTime"])
        if isinstance(DataSource["LastUpdatedTime"], str):
            pass
        else:
            DataSource["LastUpdatedTime"]=str(DataSource["LastUpdatedTime"])
        DataSourceCreatedTime=datetime.strptime(DataSource["CreatedTime"], "%Y-%m-%d %H:%M:%S.%f%z").isoformat(timespec='seconds')
        DataSourceLastUpdatedTime=datetime.strptime(DataSource["LastUpdatedTime"], "%Y-%m-%d %H:%M:%S.%f%z").isoformat(timespec='seconds')
        if "SslProperties" in DataSource:
            if "DisableSsl" in DataSource["SslProperties"]:
                DataSourceSSL=str(DataSource["SslProperties"]["DisableSsl"])
        else:
            DataSourceSSL=None
        if "ErrorInfo" in DataSource:
            DataSourceErrorMessage=DataSource["ErrorInfo"]["Message"]
            DataSourceErrorType=DataSource["ErrorInfo"]["Type"]
        else:
            DataSourceErrorMessage=None
            DataSourceErrorType=None
        if "VpcConnectionProperties" in DataSource:
            if "VpcConnectionArn" in DataSource["VpcConnectionProperties"]:
                DataSourceVPCARN=DataSource["VpcConnectionProperties"]["VpcConnectionArn"]
        else:
            DataSourceVPCARN=None
        csvWriter.writerow([DataSourceID,DataSourceName,DataSourceType,DataSourceStatus,DataSourceCreatedTime,DataSourceLastUpdatedTime,DataSourceSSL,DataSourceErrorMessage,DataSourceErrorType,DataSourceVPCARN])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(dataFile, DataLineageBucket, "DataSources/DataSource_"+DataSourceID+"_.csv")     
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_generateDataSources_"+DataSourceID+".csv")
        #Open a CSV file to write the exception
        print(["Exception in generateDataSources_"+DataSourceID,str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in generateDataSources_"+DataSourceID,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_generateDataSources_"+DataSourceID+".csv")

#Iterate through list of QuickSight resources
def iterateResources(QuickSightResource,resourceName):
    try:
        #Check if QuickSightResource is a list or string
        if type(QuickSightResource) is list:
            for Resource in QuickSightResource:
                if resourceName=="Analysis":
                    describeResource(Resource["AnalysisId"],"Analysis")
                    describeResourcePermissions(Resource["AnalysisId"],"Analysis")
                    describeAnalysisDefinition(Resource["AnalysisId"])
                    #time.sleep(0.26)
                elif resourceName=="Dashboard":
                    describeResource(Resource["DashboardId"],"Dashboard")
                    describeResourcePermissions(Resource["DashboardId"],"Dashboard")
                    describeDashboardDefinition(Resource["DashboardId"])
                    #time.sleep(0.26)
                elif resourceName=="DataSource":
                    generateDataSources(Resource)
                    describeResourcePermissions(Resource["DataSourceId"],"DataSource")
                    #time.sleep(0.26)
                elif resourceName=="DataSet":
                    describeDataSet(Resource["DataSetId"])
                    describeResourcePermissions(Resource["DataSetId"],"DataSet")
                    #time.sleep(0.26)
                else:
                    print("Resource not found")
                #Add a delay of 0.26 seconds
                #time.sleep(0.26)
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_iterateResources_"+resourceName+".csv")
        #Open a CSV file to write the exception
        print(["Exception in iterateResources",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in iterateResources_"+resourceName,str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_iterateResources_"+resourceName+".csv")
                
#Get list of QuickSight Analysis
def listAnalyses(nextToken):
    try:
        #Get the list of Analyses if NextToken equals "first":
        if nextToken=="first":
            listAnalysis=quicksight.list_analyses(AwsAccountId=awsAccountId,MaxResults=100)
        #Check if NextToken has a value
        elif nextToken!=None and nextToken!="first":
            listAnalysis=quicksight.list_analyses(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            listAnalysis=quicksight.list_analyses(AwsAccountId=awsAccountId,MaxResults=100)
        #Get the Analysis ID
        #for Analysis in listAnalysis["AnalysisSummaryList"]:
        #iterateResources(listAnalysis["AnalysisSummaryList"],"Analysis")
        event = {"body": { "invocationType": "self", "quickSightResource": listAnalysis["AnalysisSummaryList"], "resourceName":"Analysis" }}
        response = lambdaClient.invoke(
        FunctionName=LambdaFunctionName,
        InvocationType='Event',
        LogType='None',
        Payload=json.dumps(event,default=str)
        )
        #Check if NextToken is present
        if "NextToken" in listAnalysis:
            listAnalyses(listAnalysis["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listAnalysis.csv")
        #Open a CSV file to write the exception
        print(["Exception in listAnalysis",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listAnalysis",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listAnalysis.csv")

#Get list of QuickSight Dashboards
def listDashboards(nextToken):
    try:
        #Get the list of Dashboards if NextToken equals "first":
        if nextToken=="first":
            listDashboard=quicksight.list_dashboards(AwsAccountId=awsAccountId,MaxResults=100)
        #Check if NextToken has a value
        elif nextToken!=None and nextToken!="first":
            listDashboard=quicksight.list_dashboards(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            listDashboard=quicksight.list_dashboards(AwsAccountId=awsAccountId,MaxResults=100)
        #Get the Dashboard ID
        #for Dashboard in listDashboard["DashboardSummaryList"]:
        #iterateResources(listDashboard["DashboardSummaryList"],"Dashboard")
        event = {"body": { "invocationType": "self", "quickSightResource": listDashboard["DashboardSummaryList"], "resourceName":"Dashboard" }}
        response = lambdaClient.invoke(
        FunctionName=LambdaFunctionName,
        InvocationType='Event',
        LogType='None',
        Payload=json.dumps(event,default=str)
        )
        #Check if NextToken is present
        if "NextToken" in listDashboard:
            listDashboards(listDashboard["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listDashboard.csv")
        #Open a CSV file to write the exception
        print(["Exception in listDashboard",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listDashboard",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listDashboard.csv")

#Get list of QuickSight Data Sources
def listDataSources(nextToken):
    try:
        if nextToken=="first":
            listDataSource=quicksight.list_data_sources(AwsAccountId=awsAccountId,MaxResults=100)
        elif nextToken!=None and nextToken!="first":
            listDataSource=quicksight.list_data_sources(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            listDataSource=quicksight.list_data_sources(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        if listDataSource["DataSources"]:
            #for DataSource in listDataSource["DataSources"]:
            #iterateResources(listDataSource["DataSources"],"DataSource")
            event = {"body": { "invocationType": "self", "quickSightResource": listDataSource["DataSources"], "resourceName":"DataSource" }}
            response = lambdaClient.invoke(
            FunctionName=LambdaFunctionName,
            InvocationType='Event',
            LogType='None',
            Payload=json.dumps(event,default=str)
            )
        #Check if NextToken is present
        if "NextToken" in listDataSource:
            listDataSources(listDataSource["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listDataSource.csv")
        #Open a CSV file to write the exception
        print(["Exception in listDataSource",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listDataSource",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listDataSource.csv")

#Get list of QuickSight DataSets
def listDataSets(nextToken):
    try:
        if nextToken=="first":
            listDataSet=quicksight.list_data_sets(AwsAccountId=awsAccountId,MaxResults=100)
        elif nextToken!=None and nextToken!="first":
            listDataSet=quicksight.list_data_sets(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            listDataSet=quicksight.list_data_sets(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        if listDataSet["DataSetSummaries"]:
            #for DataSet in listDataSet["DataSetSummaries"]:
            #iterateResources(listDataSet["DataSetSummaries"],"DataSet")
            event = {"body": { "invocationType": "self", "quickSightResource": listDataSet["DataSetSummaries"], "resourceName":"DataSet" }}
            response = lambdaClient.invoke(
            FunctionName=LambdaFunctionName,
            InvocationType='Event',
            LogType='None',
            Payload=json.dumps(event,default=str)
            )
        if "NextToken" in listDataSet:
            listDataSets(listDataSet["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listDataSet.csv")
        #Open a CSV file to write the exception
        print(["Exception in listDataSet",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listDataSet",str(e),traceback.format_exc()])
        csvWriter.writerow(["Exception in listDataSet",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listDataSet.csv")            

#Get list of QuickSight users
def getUsers(namespace,csvWriter,nextToken):
    try:
        NamespaceCreationStatus=namespace["CreationStatus"]
        NamespaceName=namespace["Name"]
        if "CapacityRegion" in namespace:
            NamespaceCapacityRegion=namespace["CapacityRegion"]
        else:
            NamespaceCapacityRegion=None
        if "IdentityStore" in namespace:
            NamespaceIdentityStore=namespace["IdentityStore"]
        else:
            NamespaceIdentityStore=None
        #Check if NamespaceError is present
        if "NamespaceError" in namespace:
            NamespaceErrorMessage=namespace["NamespaceError"]["Message"]
            NamespaceErrorType=namespace["NamespaceError"]["Type"]
        else:
            NamespaceErrorMessage=None
            NamespaceErrorType=None
        #Check NamespaceCreationStatus is CREATED
        if NamespaceCreationStatus=="CREATED":
        #Get the list of users
            if nextToken=="first":
                userList=quicksight.list_users(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName)
            elif nextToken!=None and nextToken!="first":
                userList=quicksight.list_users(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName,NextToken=nextToken)
            else:
                userList=quicksight.list_users(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName,NextToken=nextToken)
            #Get the User ID
            for User in userList["UserList"]:
                UserName=User["UserName"]
                UserRole=User["Role"]
                IdentityType=User["IdentityType"]
                UserActive=str(User["Active"])
                NamespaceUserName=NamespaceName+"/"+UserName
                csvWriter.writerow([UserName,UserRole,IdentityType,UserActive,NamespaceName,NamespaceCapacityRegion,NamespaceCreationStatus,NamespaceIdentityStore,NamespaceErrorMessage,NamespaceErrorType,NamespaceUserName])
            #Check if NextToken is present
            if "NextToken" in userList:
                getUsers(namespace,csvWriter,userList["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_getUsers.csv")
        #Open a CSV file to write the exception
        print(["Exception in getUsers",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in getUsers",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_getUsers.csv")

#Get list of QuickSight Group Members
def getGroupMembers(GroupName,csvWriter,NamespaceName,nextToken):
    try:
        #Get the list of Group Members
        if nextToken=="first":
            groupMemberList=quicksight.list_group_memberships(AwsAccountId=awsAccountId,GroupName=GroupName,MaxResults=100,Namespace=NamespaceName)
        elif nextToken!=None and nextToken!="first":
            groupMemberList=quicksight.list_group_memberships(AwsAccountId=awsAccountId,GroupName=GroupName,MaxResults=100,NextToken=nextToken,Namespace=NamespaceName)
        else:
            groupMemberList=quicksight.list_group_memberships(AwsAccountId=awsAccountId,GroupName=GroupName,MaxResults=100,NextToken=nextToken,Namespace=NamespaceName)
        #Get the Group Member ID if groupMemberList is not empty
        if groupMemberList["GroupMemberList"]:
            for GroupMember in groupMemberList["GroupMemberList"]:
                GroupMemberName=GroupMember["MemberName"]
                csvWriter.writerow([GroupName,GroupMemberName,NamespaceName])
        #Check if NextToken is present
        if "NextToken" in groupMemberList:
            getGroupMembers(GroupName,csvWriter,NamespaceName,groupMemberList["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_getGroupMembers.csv")
        #Open a CSV file to write the exception
        print(["Exception in getGroupMembers",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])

#Get list of QuickSight Groups
def getGroups(namespace,nextToken):
    try:
        NamespaceCreationStatus=namespace["CreationStatus"]
        NamespaceName=namespace["Name"]
        #Check NamespaceCreationStatus is CREATED
        if NamespaceCreationStatus=="CREATED":
            dataFilePath=path+"Groups"
            if not os.path.exists(dataFilePath):
                os.mkdir(dataFilePath)
            dataFile=os.path.join(dataFilePath,"Groups_"+NamespaceName+".csv")
            #Open a CSV file to write the data
            csvFile = open(dataFile, "w")
            csvWriter = csv.writer(csvFile)
            csvWriter.writerow(["Group_Name","Group_Member_Name","Namespace_Name"])
            #Get the list of groups
            if nextToken=="first":
                groupList=quicksight.list_groups(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName)
            elif nextToken!=None and nextToken!="first":
                groupList=quicksight.list_groups(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName,NextToken=nextToken)
            else:
                groupList=quicksight.list_groups(AwsAccountId=awsAccountId,MaxResults=100,Namespace=NamespaceName,NextToken=nextToken)
            #Get the Group ID if groupList is not empty
            if groupList["GroupList"]:
                for Group in groupList["GroupList"]:
                    GroupName=Group["GroupName"]
                    getGroupMembers(GroupName,csvWriter,NamespaceName,"first")
            #Check if NextToken is present
            if "NextToken" in groupList:
                getGroups(namespace,groupList["NextToken"])
            csvFile.close()
            #Upload file to S3
            s3.upload_file(dataFile, DataLineageBucket, "Groups/Groups_"+NamespaceName+".csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_getGroups_"+NamespaceName+".csv")
        #Open a CSV file to write the exception
        print(["Exception in getGroups",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in getGroups",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_getGroups_"+NamespaceName+".csv")

#Get list of QuickSight Namespace and invoke getUsers function
def listNamespaces(nextToken):
    try:
        dataFilePath=path+"Users"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,"Users.csv")
        #Open a CSV file to write the data
        csvFile = open(dataFile, "a")
        csvWriter = csv.writer(csvFile)
        if nextToken=="first":
            namespaceList=quicksight.list_namespaces(AwsAccountId=awsAccountId,MaxResults=100)
            csvWriter.writerow(["User_Name","User_Role","Identity_Type","User_Active","Namespace_Name","Namespace_Capacity_Region","Namespace_Creation_Status","Namespace_Identity_Store","Namespace_Error_Message","Namespace_Error_Type","Namespace_UserName"])
        elif nextToken!=None and nextToken!="first":
            namespaceList=quicksight.list_namespaces(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            namespaceList=quicksight.list_namespaces(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        #Iterate through the list of Namespace
        for Namespace in namespaceList["Namespaces"]:
            #Get the Users
            getUsers(Namespace,csvWriter,"first")
            #Get the Groups
            getGroups(Namespace,"first")
            #Add a delay of 0.26 second
            time.sleep(0.26)
        csvFile.close()
        #Check if NextToken is present
        if "NextToken" in namespaceList:
            listNamespaces(namespaceList["NextToken"])
        #Upload file to S3
        s3.upload_file(dataFile, DataLineageBucket, "Users/Users.csv")
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listNamespaces.csv")
        #Open a CSV file to write the exception
        print(["Exception in listNamespaces",str(e),traceback.format_exc()])
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listNamespaces",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listNamespaces.csv")

#Get list of QuickSight Folder Members
def getFolderMembers(Folder,csvWriter,nextToken):
    try:
        FolderId=Folder["FolderId"]
        FolderName=Folder["Name"]
        FolderType=Folder["FolderType"]
        FolderCreatedTime=Folder["CreatedTime"].isoformat(timespec='seconds')
        FolderLastUpdatedTime=Folder["LastUpdatedTime"].isoformat(timespec='seconds')
        if "SharingModel" in Folder:
            FolderSharingModel=Folder["SharingModel"]
        else:
            FolderSharingModel=None
        if nextToken=="first":
            folderMembers=quicksight.list_folder_members(AwsAccountId=awsAccountId,FolderId=FolderId,MaxResults=100)
        elif nextToken!=None and nextToken!="first":
            folderMembers=quicksight.list_folder_members(AwsAccountId=awsAccountId,FolderId=FolderId,MaxResults=100,NextToken=nextToken)
        else:
            folderMembers=quicksight.list_folder_members(AwsAccountId=awsAccountId,FolderId=FolderId,MaxResults=100,NextToken=nextToken)
        #Iterate through the list of Folder Members if folderMembers is not empty
        if folderMembers["FolderMemberList"]:
            for FolderMember in folderMembers["FolderMemberList"]:
                if "MemberId" in FolderMember:
                    FolderMemberId=FolderMember["MemberId"]
                else:   
                    FolderMemberId=None
                if "MemberArn" in FolderMember:
                    if "dashboard" in FolderMember["MemberArn"]:
                        FolderMemberType="Dashboard"
                    elif "dataset" in FolderMember["MemberArn"]:
                        FolderMemberType="DataSet"
                    elif "analysis" in FolderMember["MemberArn"]:
                        FolderMemberType="Analysis"
                    else:
                        FolderMemberType=FolderMember["MemberArn"]
                    FolderMemberArn=FolderMember["MemberArn"]
                else:
                    FolderMemberType=None
                #Write the data to CSV file
                csvWriter.writerow([FolderName,FolderId,FolderType,FolderCreatedTime,FolderLastUpdatedTime,FolderSharingModel,FolderMemberType,FolderMemberId])
        #Check if NextToken is present
        if "NextToken" in folderMembers:
            getFolderMembers(Folder,csvWriter,folderMembers["NextToken"])
    except Exception as e:
        print(["Exception in getFolderMembers",str(e),traceback.format_exc()])
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_getFolderMembers.csv")
        #Open a CSV file to write the exception
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in getFolderMembers",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_getFolderMembers_"+FolderName+".csv")

#Get list of QuickSight Folders
def listFolders(nextToken):
    try:
        dataFilePath=path+"Folders"
        if not os.path.exists(dataFilePath):
            os.mkdir(dataFilePath)
        dataFile=os.path.join(dataFilePath,"Folders.csv")
        #Open a CSV file to write the data
        csvFile = open(dataFile, "a")
        csvWriter = csv.writer(csvFile)
        if nextToken=="first":
            folderList=quicksight.list_folders(AwsAccountId=awsAccountId,MaxResults=100)
            csvWriter.writerow(["Folder_Name","Folder_Id","Folder_Type","Folder_Created_Time","Folder_Last_Updated_Time","Folder_Sharing_Model","Folder_Member_Type","Folder_Member_ID"])
        elif nextToken!=None and nextToken!="first":
            folderList=quicksight.list_folders(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            folderList=quicksight.list_folders(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        #Get the Folder ID if folderList is not empty
        if folderList["FolderSummaryList"]:
            for Folder in folderList["FolderSummaryList"]:
                getFolderMembers(Folder,csvWriter,"first")
                describeResourcePermissions(Folder["FolderId"],"Folder")
                #Add delay of 0.26 second
                time.sleep(0.26)
        csvFile.close()
        #Upload to S3
        s3.upload_file(dataFile, DataLineageBucket, "Folders/Folders.csv")
        #Check if NextToken is present
        if "NextToken" in folderList:
            listFolders(folderList["NextToken"])
    except Exception as e:
        print(["Exception in listFolder",str(e),traceback.format_exc()])
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listFolder.csv")
        #Open a CSV file to write the exception
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listFolder",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listFolder.csv")

#Get list of QuickSight Templates
def listTemplates(nextToken):
    try:
        if nextToken=="first":
            templateList=quicksight.list_templates(AwsAccountId=awsAccountId,MaxResults=100)
        elif nextToken!=None and nextToken!="first":
            templateList=quicksight.list_templates(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        else:
            templateList=quicksight.list_templates(AwsAccountId=awsAccountId,MaxResults=100,NextToken=nextToken)
        if "TemplateSummaryList" in templateList:
            if templateList["TemplateSummaryList"]:
                for Template in templateList["TemplateSummaryList"]:
                    describeResourcePermissions(Template["TemplateId"],"Template")
                    describeResource(Template["TemplateId"],"Template")
                    #Add delay of 0.26 seconds
                    time.sleep(0.26)
        #Check if NextToken is present
        if "NextToken" in templateList:
            listTemplates(templateList["NextToken"])
    except Exception as e:
        errorFilePath=path+"Errors"
        if not os.path.exists(errorFilePath):
            os.mkdir(errorFilePath)
        errorFile=os.path.join(errorFilePath,"Exception_listTemplates.csv")
        print(["Exception in listTemplates",str(e),traceback.format_exc()])
        #Open a CSV file to write the exception
        csvFile = open(errorFile, "w")
        csvWriter = csv.writer(csvFile,quoting=csv.QUOTE_ALL)
        csvWriter.writerow(["Exception_Type","Exception_Message","Exception_StackTrace"])
        csvWriter.writerow(["Exception in listTemplates",str(e),traceback.format_exc()])
        csvFile.close()
        #Upload file to S3
        s3.upload_file(errorFile, DataLineageBucket, "Errors/Exception_listTemplates.csv")

def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False, reason=None):
        responseUrl = event['ResponseURL']
        http = urllib3.PoolManager()
        print(responseUrl)

        responseBody = {
            'Status' : responseStatus,
            'Reason' : reason or "See the details in CloudWatch Log Stream: {}".format(context.log_stream_name),
            'PhysicalResourceId' : physicalResourceId or context.log_stream_name,
            'StackId' : event['StackId'],
            'RequestId' : event['RequestId'],
            'LogicalResourceId' : event['LogicalResourceId'],
            'NoEcho' : noEcho,
            'Data' : responseData
        }

        json_responseBody = json.dumps(responseBody)

        print("Response body:")
        print(json_responseBody)

        headers = {
            'content-type' : '',
            'content-length' : str(len(json_responseBody))
        }

        try:
            response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)
            print("Status code:", response.status)
            
        except Exception as e:
            print("send(..) failed executing http.request(..):", e)

def createAthenaTables():
    createDataBaseDLL="CREATE DATABASE IF NOT EXISTS "+databaseName+";"
    athenaDLLList=["CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysiscalculatedfields`(   `cf_dataset_name` string,    `calculated_field_name` string,    `calculated_field_expression` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisCalculatedFields/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='true',    'averageRecordSize'='80',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='81',    'recordCount'='320',    'sizeKey'='34181',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysisdatasets`(   `dataset_name` string,    `dataset_id` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisDataSets/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='50',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='536',    'recordCount'='1108',    'sizeKey'='70646',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysisdescription`(   `analysis_id` string,    `analysis_name` string,    `analysis_created_time` string,    `analysis_last_updated_time` string,    `theme` string,    `resourcestatus` bigint) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisDescription/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='96',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='558',    'recordCount'='1116',    'sizeKey'='119782',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysisfilters`(   `filter_group_id` string,    `filter_status` string,    `filter_dataset_scope` string,    `filter_type` string,    `filter_id` string,    `filter_column` string,    `filter_column_dataset` string,    `filter_sheet_id` string,    `filter_scope` string,    `filter_visual_id` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisFilters/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='204',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='122',    'recordCount'='518',    'sizeKey'='120654',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysisparameters`(   `parameter_type` string,    `parameter_value_type` string,    `parameter_name` string,    `parameter_static_default_value` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisParameters/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='73',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='60',    'recordCount'='175',    'sizeKey'='14731',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysispermissions`(   `analysis_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisPermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='59',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='518',    'recordCount'='1046',    'sizeKey'='76589',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysissheetfiltercontrols`(   `filter_control_id` string,    `filter_control_name` string,    `filter_control_type` string,    `filter_control_source_id` string,    `filter_control_select_type` string,    `filter_control_sheetid` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisSheetFilterControls/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='160',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='29',    'recordCount'='69',    'sizeKey'='11630',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysissheetparametercontrols`(   `parameter_control_id` string,    `parameter_control_name` string,    `parameter_control_type` string,    `parameter_control_source` string,    `parameter_control_select_type` string,    `parameter_control_sheetid` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisSheetParameterControls/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='151',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='48',    'recordCount'='123',    'sizeKey'='20834',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysissheets`(   `sheet_name` string,    `sheet_id` string,    `sheet_type` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisSheets/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='62',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='550',    'recordCount'='1178',    'sizeKey'='83397',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-analysissheetvisuals`(   `visual_type` string,    `visual_id` string,    `visual_title` string,    `visual_title_visibility` string,    `visual_field_name` string,    `visual_field_type` string,    `visual_field_id` string,    `visual_field_dataset_name` string,    `visual_sheetid` string,    `analysis_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/AnalysisSheetVisuals/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='true',    'averageRecordSize'='164',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='623',    'recordCount'='3909',    'sizeKey'='824353',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardcalculatedfields`(   `cf_dataset_name` string,    `calculated_field_name` string,    `calculated_field_expression` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardCalculatedFields/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='true',    'averageRecordSize'='86',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='49',    'recordCount'='1006',    'sizeKey'='98827',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboarddatasets`(   `dataset_name` string,    `dataset_id` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardDataSets/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='51',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='134',    'recordCount'='295',    'sizeKey'='19134',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboarddescription`(   `dashboard_id` string,    `dashboard_name` string,    `dashboard_created_time` string,    `dashboard_last_updated_time` string,    `dashboard_last_published_time` string,    `dashboard_version_created_time` string,    `dashboard_version_description` string,    `dashboard_version_source_entity_type` string,    `dashboard_version_source_entity_id` string,    `dashboard_version_number` bigint,    `dashboard_version_theme` string,    `dashboard_version_status` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardDescription/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='237',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='139',    'recordCount'='278',    'sizeKey'='68580',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardfilters`(   `filter_group_id` string,    `filter_status` string,    `filter_dataset_scope` string,    `filter_type` string,    `filter_id` string,    `filter_column` string,    `filter_column_dataset` string,    `filter_sheet_id` string,    `filter_scope` string,    `filter_visual_id` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardFilters/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='232',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='58',    'recordCount'='1973',    'sizeKey'='479156',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardparameters`(   `parameter_type` string,    `parameter_value_type` string,    `parameter_name` string,    `parameter_static_default_value` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardParameters/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='71',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='48',    'recordCount'='204',    'sizeKey'='16750',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardpermissions`(   `dashboard_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardPermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='59',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='139',    'recordCount'='322',    'sizeKey'='24642',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardsheetfiltercontrols`(   `filter_control_id` string,    `filter_control_name` string,    `filter_control_type` string,    `filter_control_source_id` string,    `filter_control_select_type` string,    `filter_control_sheetid` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardSheetFilterControls/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='174',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='24',    'recordCount'='68',    'sizeKey'='12643',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardsheetparametercontrols`(   `parameter_control_id` string,    `parameter_control_name` string,    `parameter_control_type` string,    `parameter_control_source` string,    `parameter_control_select_type` string,    `parameter_control_sheetid` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardSheetParameterControls/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='146',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='53',    'recordCount'='183',    'sizeKey'='31426',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardsheets`(   `sheet_name` string,    `sheet_id` string,    `sheet_type` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardSheets/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='60',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='137',    'recordCount'='373',    'sizeKey'='31722',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-dashboardsheetvisuals`(   `visual_type` string,    `visual_id` string,    `visual_title` string,    `visual_title_visibility` string,    `visual_field_name` string,    `visual_field_type` string,    `visual_field_id` string,    `visual_field_dataset_name` string,    `visual_sheetid` string,    `dashboard_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DashboardSheetVisuals/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='true',    'averageRecordSize'='204',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='223',    'recordCount'='3400',    'sizeKey'='842901',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-datasetpermissions`(   `dataset_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DataSetPermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='57',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='588',    'recordCount'='1102',    'sizeKey'='80281',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-datasets`(   `dataset_id` string,    `dataset_name` string,    `dataset_cls_enabled` boolean,    `dataset_creation_time` string,    `dataset_last_updated_time` string,    `dataset_disable_useasdirectquerysource` boolean,    `dataset_useasimportedsource` boolean,    `dataset_import_mode` string,    `dataset_rls_status` string,    `dataset_rls_arn` string,    `dataset_rls_tags_status` string,    `dataset_spice_capacity` bigint) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DataSets/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='195',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='360',    'recordCount'='720',    'sizeKey'='150418',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-datasetscolumns`(   `dataset_id` string,    `dataset_column_name` string,    `dataset_column_type` string,    `dataset_column_description` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DataSetsColumns/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='50',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='360',    'recordCount'='6586',    'sizeKey'='442065',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-datasourcepermissions`(   `datasource_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DataSourcePermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='57',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='985',    'recordCount'='1867',    'sizeKey'='138854',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-datasources`(   `data_source_id` string,    `data_source_name` string,    `data_source_type` string,    `data_source_status` string,    `data_source_created_time` string,    `data_source_last_updated_time` string,    `data_source_disable_ssl` boolean,    `data_source_error_message` string,    `data_source_error_type` string,    `data_source_vpc_arn` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/DataSources/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='159',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='984',    'recordCount'='1968',    'sizeKey'='340295',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-errors`(   `exception_type` string,    `exception_message` string,    `exception_stacktrace` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/Errors/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='true',    'averageRecordSize'='407',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='988',    'recordCount'='1976',    'sizeKey'='887861',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-folderpermissions`(   `folder_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/FolderPermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='69',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='14',    'recordCount'='33',    'sizeKey'='2421',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-folders`(   `folder_name` string,    `folder_id` string,    `folder_type` string,    `folder_created_time` string,    `folder_last_updated_time` string,    `folder_sharing_model` string,    `folder_member_type` string,    `folder_member_id` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/Folders/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='154',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='1',    'recordCount'='14',    'sizeKey'='2160',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-groups`(   `group_name` string,    `group_member_name` string,    `namespace_name` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/Groups/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='27',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='7',    'recordCount'='33',    'sizeKey'='1026',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-templatedescription`(   `template_id` string,    `template_name` string,    `template_created_time` string,    `template_last_updated_time` string,    `template_version_created_time` string,    `template_version_description` string,    `template_version_source_entity_type` string,    `template_version_source_entity_id` string,    `template_version_number` bigint,    `template_version_status` string,    `template_version_theme` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/TemplateDescription/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='227',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='24',    'recordCount'='48',    'sizeKey'='11257',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-templatepermissions`(   `template_id` string,    `principal_name` string,    `principal_type` string,    `permission_type` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/TemplatePermissions/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='51',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='24',    'recordCount'='45',    'sizeKey'='2566',    'skip.header.line.count'='1',    'typeOfData'='file')",   "CREATE EXTERNAL TABLE IF NOT EXISTS `qs-users`(   `user_name` string,    `user_role` string,    `identity_type` string,    `user_active` boolean,    `namespace_name` string,    `namespace_capacity_region` string,    `namespace_creation_status` string,    `namespace_identity_store` string,    `namespace_error_message` string,    `namespace_error_type` string,    `namespace_username` string) ROW FORMAT DELIMITED    FIELDS TERMINATED BY ','  STORED AS INPUTFORMAT    'org.apache.hadoop.mapred.TextInputFormat'  OUTPUTFORMAT    'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' LOCATION   's3://"+DataLineageBucket+"/Users/' TBLPROPERTIES (   'CrawlerSchemaDeserializerVersion'='1.0',    'CrawlerSchemaSerializerVersion'='1.0',    'UPDATED_BY_CRAWLER'='quicksightdatalineage',    'areColumnsQuoted'='false',    'averageRecordSize'='144',    'classification'='csv',    'columnsOrdered'='true',    'compressionType'='none',    'customSerde'='LazySimpleSerDe',    'delimiter'=',',    'objectCount'='1',    'recordCount'='42',    'sizeKey'='6180',    'skip.header.line.count'='1',    'typeOfData'='file')" ]
    try:
        createDataBase=athena.start_query_execution(
            QueryString=createDataBaseDLL,
            QueryExecutionContext={
                'Catalog': 'AwsDataCatalog'
            },
            ResultConfiguration={
                'OutputLocation': "s3://"+DataLineageBucket+"/AthenaQueryResults",
                'EncryptionConfiguration': {
                    'EncryptionOption': 'SSE_S3'
                }
            }
        )
        
        for dll in athenaDLLList:
            createTable=athena.start_query_execution(
                QueryString=dll,
                QueryExecutionContext={
                    'Catalog': 'AwsDataCatalog',
                    'Database': databaseName
                },
                ResultConfiguration={
                    'OutputLocation': "s3://"+DataLineageBucket+"/AthenaQueryResults",
                    'EncryptionConfiguration': {
                        'EncryptionOption': 'SSE_S3'
                    }
                }
            )
            time.sleep(0.5)
        return "success"
            
    except Exception as e:
        return "failed"
        
def createQuickSightAssets():
    try:
        qsUserARN = quicksight.describe_user(
            UserName=userName,
            AwsAccountId=awsAccountId,
            Namespace=namespace
        )['User']['Arn']
        
        qsAssets = quicksight.start_asset_bundle_import_job(
            AwsAccountId=awsAccountId,
            AssetBundleImportJobId=qsImportJobID,
            AssetBundleImportSource={
                'S3Uri': "s3://"+codeBucket+"/assetbundle-qs-dl.qs"
            },
            FailureAction='ROLLBACK',
            OverridePermissions={
                'DataSources': [
                    {
                        'DataSourceIds': [
                            'qs-datalineage-83d0d823-6cf7-4409-9a2a-1d774c429be4',
                        ],
                        'Permissions': {
                            'Principals': [
                                qsUserARN
                            ],
                            'Actions': [
        		                "quicksight:PassDataSource",
        		                "quicksight:DescribeDataSourcePermissions",
        		                "quicksight:UpdateDataSource",
        		                "quicksight:UpdateDataSourcePermissions",
        		                "quicksight:DescribeDataSource",
        		                "quicksight:DeleteDataSource"
        		            ]
                        }
                    },
                ],
                'DataSets': [
                    {
                        'DataSetIds': [
                            'qs-datalineage-1a92a3fb-552e-468c-ab93-85b0e7014825',
                            'qs-datalineage-6069011e-9a5a-4ccd-89bb-36ddfc4c2ed6',
                            'qs-datalineage-5d360c46-8ae1-4e44-ba32-e300de47f86f',
                            'qs-datalineage-066f3e0a-9fcd-4104-a9ff-b6d5a47e8094',
                            'qs-datalineage-d026aa27-93ed-4b8f-91c2-bceccbd3aca6',
                            'qs-datalineage-782a9304-961b-4cf5-8893-d06cc3a4d3df',
                            'qs-datalineage-fb16efbf-268c-49c2-9078-e83d38d57f2e',
                            'qs-datalineage-29ff98d8-5e24-4d42-85d6-9262688b3a8b',
                            'qs-datalineage-6d4a456f-b564-4540-b783-f414e829986f'
                        ],
                        'Permissions': {
                            'Principals': [
                                qsUserARN
                            ],
                            'Actions': [
        		                "quicksight:DeleteDataSet",
        		                "quicksight:UpdateDataSetPermissions",
        		                "quicksight:PutDataSetRefreshProperties",
        		                "quicksight:CreateRefreshSchedule",
        		                "quicksight:CancelIngestion",
        		                "quicksight:ListRefreshSchedules",
        		                "quicksight:UpdateRefreshSchedule",
        		                "quicksight:PassDataSet",
        		                "quicksight:DeleteRefreshSchedule",
        		                "quicksight:DescribeDataSetRefreshProperties",
        		                "quicksight:DescribeDataSet",
        		                "quicksight:CreateIngestion",
        		                "quicksight:DescribeRefreshSchedule",
        		                "quicksight:ListIngestions",
        		                "quicksight:UpdateDataSet",
        		                "quicksight:DescribeDataSetPermissions",
        		                "quicksight:DeleteDataSetRefreshProperties",
        		                "quicksight:DescribeIngestion"
        		            ]
                        }
                    },
                ],
                'Themes': [
                    {
                        'ThemeIds': [
                            'qs-datalineage-anymotorsmonthly',
                        ],
                        'Permissions': {
                            'Principals': [
                                qsUserARN
                            ],
                            'Actions': [
        		                "quicksight:UpdateThemeAlias",
        		                "quicksight:ListThemeVersions",
        		                "quicksight:DescribeThemeAlias",
        		                "quicksight:UpdateThemePermissions",
        		                "quicksight:DeleteThemeAlias",
        		                "quicksight:DeleteTheme",
        		                "quicksight:ListThemeAliases",
        		                "quicksight:DescribeTheme",
        		                "quicksight:CreateThemeAlias",
        		                "quicksight:UpdateTheme",
        		                "quicksight:DescribeThemePermissions"
        		            ]
                        }
                    },
                ],
                'Analyses': [
                    {
                        'AnalysisIds': [
                            'qs-datalineage-19ae04a6-3218-4724-968c-8721f16d3602',
                        ],
                        'Permissions': {
                            'Principals': [
                                qsUserARN
                            ],
                            'Actions': [
        		                "quicksight:RestoreAnalysis",
        		                "quicksight:UpdateAnalysisPermissions",
        		                "quicksight:DeleteAnalysis",
        		                "quicksight:DescribeAnalysisPermissions",
        		                "quicksight:QueryAnalysis",
        		                "quicksight:DescribeAnalysis",
        		                "quicksight:UpdateAnalysis"
        		            ]
                        }
                    },
                ],
                'Dashboards': [
                    {
                        'DashboardIds': [
                            'qs-datalineage-2ee1a495-9cb6-4573-b0d6-0b22d80b6ce3',
                        ],
                        'Permissions': {
                            'Principals': [
                                qsUserARN
                            ],
                            'Actions': [
        		                "quicksight:DescribeDashboard",
        		                "quicksight:ListDashboardVersions",
        		                "quicksight:UpdateDashboardPermissions",
        		                "quicksight:QueryDashboard",
        		                "quicksight:UpdateDashboard",
        		                "quicksight:DeleteDashboard",
        		                "quicksight:DescribeDashboardPermissions",
        		                "quicksight:UpdateDashboardPublishedVersion"
        		            ]
                        }
                    }
                ]
            },
            OverrideValidationStrategy={
                'StrictModeForAllResources': True
            },
            OverrideParameters={
                'ResourceIdOverrideConfiguration': {
                    'PrefixForAllResources': "qs-datalineage-"
                }
            }
        )
        time.sleep(60)
        
        qsDescribeImport = quicksight.describe_asset_bundle_import_job(
            AwsAccountId=awsAccountId,
            AssetBundleImportJobId=qsImportJobID
        )['JobStatus']
        
        if qsDescribeImport=="SUCCESSFUL":
            return "success"
        
    except Exception as e:
        return "failed"

def checkResourceID(d,resourceType):
    for k, v in d.items():
        if isinstance(v, dict):
            checkResourceID(v,resourceType)
        elif isinstance(v, str):
            if ":"+resourceType+"/" in v:
                idList=v.split(":"+resourceType+"/")
                global resID
                resID['id']=idList[-1]
                return resID['id']
                break
            
def getEventResourceDescription(event,eventName):
    if "Analysis" in eventName:
        resourceID=checkResourceID(event['detail'],'analysis')
        print(resID['id'])
        describeResource(resID['id'],"Analysis")
        describeResourcePermissions(resID['id'],"Analysis")
        describeAnalysisDefinition(resID['id'])
        #time.sleep(0.26)
    elif "Dashboard" in eventName:
        resourceID=checkResourceID(event['detail'],'dashboard')
        print(resID['id'])
        describeResource(resID['id'],"Dashboard")
        describeResourcePermissions(resID['id'],"Dashboard")
        describeDashboardDefinition(resID['id'])
        #time.sleep(0.26)
    elif "DataSource" in eventName:
        resourceID=checkResourceID(event['detail'],'datasource')
        print(resID['id'])
        dataSource=quicksight.describe_data_source(AwsAccountId=awsAccountId,DataSourceId=resID['id'])
        generateDataSources(dataSource['DataSource'])
        describeResourcePermissions(resID['id'],"DataSource")
        #time.sleep(0.26)
    elif "DataSet" in eventName:
        resourceID=checkResourceID(event['detail'],'dataset')
        print(resID['id'])
        describeDataSet(resID['id'])
        describeResourcePermissions(resID['id'],"DataSet")
        #time.sleep(0.26)
    elif "Folder" in eventName:
        listFolders("first")
    elif "Template" in eventName:
        listTemplates("first")
    elif "Group" in eventName:
        listNamespaces("first")
    elif "GroupMembership" in eventName:
        listNamespaces("first")
    elif "RegisterUser" in eventName:
        listNamespaces("first")
    else:
        print("Event not found")
      
def deleteDescription(eventName,resourceID):
    try:
      objects=[]
      s3Keys=s3.list_objects_v2(
            Bucket=DataLineageBucket,
            Prefix=eventName.removeprefix("Delete")
      )
      for s3key in s3Keys['Contents']:
            if "_"+resourceID+"_" in s3key['Key']:
                key={}
                key['Key']=s3key['Key']
                objects.append(key)

      while "NextContinuationToken" in s3Keys:
        time.sleep(0.26)
        s3Keys=s3.list_objects_v2(
            Bucket=DataLineageBucket,
            Prefix=eventName.removeprefix("Delete"),
            ContinuationToken=s3Keys['NextContinuationToken']
        )
        for s3key in s3Keys['Contents']:
            if "_"+resourceID+"_" in s3key['Key']:
                key={}
                key['Key']=s3key['Key']
                objects.append(key)

      deleteDef = s3.delete_objects(
        Bucket=DataLineageBucket,
        Delete={
            'Objects': objects
        }
      )

    except Exception as e:
      print(str(e))
      
def deleteResourceDescription(event,eventName):
    print(eventName)
    if "Analysis" in eventName:
        resourceID=checkResourceID(event['detail'],'analysis')
        print(resID['id'])
        deleteDescription(eventName,resID['id'])
        #time.sleep(0.26)
    elif "Dashboard" in eventName:
        resourceID=checkResourceID(event['detail'],'dashboard')
        print(resID['id'])
        deleteDescription(eventName,resID['id'])
        #time.sleep(0.26)
    elif "DataSource" in eventName:
        resourceID=checkResourceID(event['detail'],'datasource')
        print(resID['id'])
        deleteDescription(eventName,resID['id'])
        #time.sleep(0.26)
    elif "DataSet" in eventName:
        resourceID=checkResourceID(event['detail'],'dataset')
        print(resID['id'])
        deleteDescription(eventName,resID['id'])
    elif "Folder" in eventName:
        listFolders("first")
    elif "Template" in eventName:
        listTemplates("first")
    elif "Group" in eventName:
        listNamespaces("first")
    elif "GroupMembership" in eventName:
        listNamespaces("first")
    elif "RegisterUser":
        listNamespaces("first")
    else:
        print("Event not found")

def checkEvent(event,eventName):
    if "Create" in eventName or "RegisterUser" in eventName:
      getEventResourceDescription(event,eventName)
    elif "Update" in eventName and "Permissions" not in eventName:
      deleteResourceDescription(event,eventName)
      getEventResourceDescription(event,eventName)
    elif "Update" in eventName and "Permissions" in eventName:
      resName = ''
      for ix in range(eventName.index("Update") + len("Update") + 1, eventName.index("Permissions")):
          resName = resName + eventName[ix]
      resourceID=eventResourceID=checkResourceID(event['detail'],resName.lower())
      describeResourcePermissions(resID['id'],resName)
    elif "Delete" in eventName:
      deleteResourceDescription(event,eventName)
        
def handler(event, context):
    if "body" in event:
        if "invocationType" in event["body"]:
            if event["body"]["invocationType"] == "self":
                print("inside self invocation")
                QuickSightResource=event["body"]["quickSightResource"]
                ResourceName=event["body"]["resourceName"]
                iterateResources(QuickSightResource,ResourceName)
                
    if "detail" in event:
        if "serviceEventDetails" in event['detail']:
            checkEvent(event,event['detail']['eventName'])

    if "RequestType" in event:    
        if event['RequestType'] == 'Create':
            listAnalyses("first")
            listDashboards("first")
            listNamespaces("first")
            listFolders("first")
            listDataSources("first")
            listDataSets("first")
            listTemplates("first")
            if createAthenaTables() == "success":
                if createQuickSightAssets() == "success":
                    result, response = (True, "QuickSight object description created. Please check Errors folder in S3 bucket.")
                else:
                    result, response = (False, "QuickSight resources creation failed. Please check CloudWatch for details.")
            else:
                result, response = (False, "Athena tables creation failed. Please check CloudWatch for details.")
        elif event['RequestType'] == 'Update':
            result, response = (True, "Update method not implemented")
        elif event['RequestType'] == 'Delete':
            result, response = (True, "Delete method not implemented")
        else:
            result = False
            response = "Unknown operation: " + event['RequestType']

        responseData = {}
        responseData['Response'] = response
 
        if result:
          send(event, context, "SUCCESS", responseData, LambdaFunctionName)
        else:
          send(event, context, "FAILED", responseData, LambdaFunctionName)
